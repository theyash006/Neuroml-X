package com.tracetoxic.ai.auth

import com.tracetoxic.ai.core.model.AgeMode
import java.time.LocalDate
import java.time.Period

/**
 * Validates Date of Birth and categorizes user into Minor or Adult Mode.
 */
class AgeVerificationManager {

    fun determineAgeMode(dateOfBirth: LocalDate, currentDate: LocalDate = LocalDate.now()): Pair<Int, AgeMode> {
        val age = Period.between(dateOfBirth, currentDate).years
        val mode = if (age < 18) AgeMode.MINOR else AgeMode.ADULT
        return Pair(age, mode)
    }
}
