package com.tracetoxic.ai.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tracetoxic.ai.core.model.AgeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate

data class AuthUiState(
    val isAuthenticated: Boolean = false,
    val userId: String? = null,
    val dateOfBirth: LocalDate? = null,
    val calculatedAge: Int? = null,
    val ageMode: AgeMode? = null,
    val guardianLinked: Boolean = false,
    val errorMessage: String? = null
)

class AuthViewModel(
    private val ageVerificationManager: AgeVerificationManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    fun setDateOfBirth(dob: LocalDate) {
        viewModelScope.launch {
            val (age, mode) = ageVerificationManager.determineAgeMode(dob)
            _uiState.value = _uiState.value.copy(
                dateOfBirth = dob,
                calculatedAge = age,
                ageMode = mode
            )
        }
    }

    fun onAuthSuccess(userId: String) {
        _uiState.value = _uiState.value.copy(
            isAuthenticated = true,
            userId = userId,
            errorMessage = null
        )
    }

    fun onAuthError(message: String) {
        _uiState.value = _uiState.value.copy(
            errorMessage = message
        )
    }

    fun setGuardianLinked(linked: Boolean) {
        _uiState.value = _uiState.value.copy(
            guardianLinked = linked
        )
    }
}
