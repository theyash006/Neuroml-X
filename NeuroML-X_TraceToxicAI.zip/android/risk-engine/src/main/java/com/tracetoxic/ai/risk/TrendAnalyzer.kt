package com.tracetoxic.ai.risk

import com.tracetoxic.ai.core.model.BullyingCategory
import com.tracetoxic.ai.core.model.Incident

/**
 * Analyzes historical trajectory to detect escalating hostility over time.
 * Always phrases insights cautiously: "The system estimates an increasing risk pattern."
 */
class TrendAnalyzer {

    data class TrendResult(
        val penaltyScore: Int,
        val trendMessage: String?
    )

    fun evaluate(currentToxicity: Float, recentHistory: List<Incident>): TrendResult {
        if (recentHistory.size < 2) return TrendResult(0, null)

        val pastToxicScores = recentHistory
            .filter { it.category != BullyingCategory.NORMAL }
            .takeLast(3)
            .map { it.toxicityScore }

        if (pastToxicScores.size >= 2) {
            val averagePast = pastToxicScores.average().toFloat()
            if (currentToxicity > averagePast + 0.20f) {
                return TrendResult(
                    penaltyScore = 15,
                    trendMessage = "The system estimates an increasing risk pattern compared to previous messages"
                )
            }
        }

        return TrendResult(0, null)
    }
}
