package com.tracetoxic.ai.risk

import com.tracetoxic.ai.core.model.BullyingCategory
import com.tracetoxic.ai.core.model.Incident
import com.tracetoxic.ai.core.model.RiskLevel
import com.tracetoxic.ai.domain.risk.RiskCalculator
import com.tracetoxic.ai.domain.risk.RiskEvaluation

class RiskCalculatorImpl(
    private val repetitionDetector: RepetitionDetector = RepetitionDetector(),
    private val trendAnalyzer: TrendAnalyzer = TrendAnalyzer()
) : RiskCalculator {

    override suspend fun calculateRisk(
        toxicityScore: Float,
        threatScore: Float,
        category: BullyingCategory,
        senderId: String,
        recentHistory: List<Incident>
    ): RiskEvaluation {
        if (category == BullyingCategory.NORMAL) {
            val lowScore = (toxicityScore * 15f).toInt()
            return RiskEvaluation(
                score = lowScore,
                level = RiskLevel.LOW,
                patterns = emptyList()
            )
        }

        val patterns = mutableListOf<String>()

        // 1. Base Score (Threat score is weighted most heavily)
        val baseScore = (toxicityScore * 35.0f) + (threatScore * 45.0f)

        // 2. Repetition Evaluation
        val repResult = repetitionDetector.evaluate(senderId, recentHistory)
        if (repResult.patternMessage != null) {
            patterns.add(repResult.patternMessage)
        }

        // 3. Escalation Trend Evaluation
        val trendResult = trendAnalyzer.evaluate(toxicityScore, recentHistory)
        if (trendResult.trendMessage != null) {
            patterns.add(trendResult.trendMessage)
        }

        // Total calculated risk normalized 0..100
        val rawTotal = baseScore + repResult.penaltyScore + trendResult.penaltyScore
        val normalizedScore = rawTotal.toInt().coerceIn(0, 100)
        val level = RiskLevel.fromScore(normalizedScore)

        return RiskEvaluation(
            score = normalizedScore,
            level = level,
            patterns = patterns
        )
    }
}
