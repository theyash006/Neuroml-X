package com.tracetoxic.ai.risk

import com.tracetoxic.ai.core.model.BullyingCategory
import com.tracetoxic.ai.core.model.Incident

/**
 * Evaluates whether the same sender has an established history of harmful messages.
 */
class RepetitionDetector {

    data class RepetitionResult(
        val penaltyScore: Int,
        val patternMessage: String?
    )

    fun evaluate(senderId: String, recentHistory: List<Incident>): RepetitionResult {
        val harmfulIncidentsFromSender = recentHistory.filter {
            it.senderId == senderId &&
            it.category != BullyingCategory.NORMAL &&
            it.toxicityScore >= 0.50f
        }

        val count = harmfulIncidentsFromSender.size
        return when {
            count >= 3 -> RepetitionResult(
                penaltyScore = 25,
                patternMessage = "Potential repeated harassment pattern detected ($count prior incidents from sender '$senderId')"
            )
            count >= 1 -> RepetitionResult(
                penaltyScore = 12,
                patternMessage = "Repeated hostile interaction detected ($count prior incident from '$senderId')"
            )
            else -> RepetitionResult(0, null)
        }
    }
}
