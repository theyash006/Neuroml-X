package com.tracetoxic.ai.risk

import com.tracetoxic.ai.core.model.BullyingCategory
import com.tracetoxic.ai.core.model.Incident
import com.tracetoxic.ai.core.model.RiskLevel
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class RiskCalculatorTest {

    private lateinit var riskCalculator: RiskCalculatorImpl

    @Before
    fun setUp() {
        riskCalculator = RiskCalculatorImpl()
    }

    @Test
    fun calculateRisk_normalMessage_returnsLowRisk() = runBlocking {
        val result = riskCalculator.calculateRisk(
            toxicityScore = 0.05f,
            threatScore = 0.0f,
            category = BullyingCategory.NORMAL,
            senderId = "user123",
            recentHistory = emptyList()
        )

        assertEquals(RiskLevel.LOW, result.level)
        assertTrue(result.score <= 25)
    }

    @Test
    fun calculateRisk_highThreat_returnsCriticalRisk() = runBlocking {
        val result = riskCalculator.calculateRisk(
            toxicityScore = 0.90f,
            threatScore = 0.95f,
            category = BullyingCategory.THREAT,
            senderId = "aggressor",
            recentHistory = emptyList()
        )

        assertEquals(RiskLevel.CRITICAL, result.level)
        assertTrue(result.score >= 76)
    }

    @Test
    fun calculateRisk_repeatedHarassment_increasesScore() = runBlocking {
        val history = listOf(
            createFakeIncident("aggressor", BullyingCategory.VERBAL_BULLYING, 0.70f),
            createFakeIncident("aggressor", BullyingCategory.VERBAL_BULLYING, 0.75f),
            createFakeIncident("aggressor", BullyingCategory.CYBERBULLYING, 0.80f)
        )

        val result = riskCalculator.calculateRisk(
            toxicityScore = 0.70f,
            threatScore = 0.20f,
            category = BullyingCategory.CYBERBULLYING,
            senderId = "aggressor",
            recentHistory = history
        )

        assertTrue(result.patterns.any { it.contains("repeated harassment pattern") })
        assertTrue(result.score > 50)
    }

    private fun createFakeIncident(sender: String, cat: BullyingCategory, toxicity: Float): Incident {
        return Incident(
            incidentId = "FAKE-ID",
            timestamp = System.currentTimeMillis(),
            appSource = "WhatsApp",
            senderId = sender,
            messageText = "Hostile message",
            category = cat,
            toxicityScore = toxicity,
            threatScore = 0.1f,
            confidence = 0.9f,
            riskScore = 55,
            riskLevel = RiskLevel.HIGH,
            explanations = emptyList()
        )
    }
}
