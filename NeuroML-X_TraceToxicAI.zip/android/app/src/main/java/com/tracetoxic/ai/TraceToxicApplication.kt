package com.tracetoxic.ai

import android.app.Application

/**
 * Main Application class for TraceToxicAI.
 * Configures Hilt dependency injection, background WorkManager routines, and crash logging.
 */
class TraceToxicApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        // Initialize security providers and WorkManager retention jobs
    }
}
