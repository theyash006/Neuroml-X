package com.tracetoxic.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.tracetoxic.ai.onboarding.NotificationAccessEducationScreen
import com.tracetoxic.ai.onboarding.PermissionVerificationManager

/**
 * Main Activity hosting Jetpack Compose UI.
 * Enforces mandatory permission check on every onResume lifecycle event.
 */
class MainActivity : ComponentActivity() {

    private lateinit var permissionManager: PermissionVerificationManager
    private val isNotificationAccessGrantedState = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        permissionManager = PermissionVerificationManager(this)

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val hasAccess by remember { isNotificationAccessGrantedState }

                    if (!hasAccess) {
                        // Hard Gate: Education Screen
                        NotificationAccessEducationScreen(
                            onOpenSettingsClick = {
                                startActivity(permissionManager.createOpenSettingsIntent())
                            },
                            onLogoutClick = {
                                finish()
                            }
                        )
                    } else {
                        // Core Dashboard unlocked
                        // AppNavHost(...)
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Re-verify actual system state on every resume (do not rely on cached booleans)
        isNotificationAccessGrantedState.value = permissionManager.isNotificationAccessGranted()
    }
}
