package com.tracetoxic.ai.notifications

/**
 * Filter that drops sensitive financial and security-related notifications
 * BEFORE sending any data to AI detection engines.
 */
class SensitiveDataFilter {

    private val otpRegexList = listOf(
        Regex("""\b(?:otp|one[- ]time[- ]password|verification code|security code)\b""", RegexOption.IGNORE_CASE),
        Regex("""\b(?:code|pin)\s*(?:is|:)?\s*\d{4,8}\b""", RegexOption.IGNORE_CASE),
        Regex("""\b\d{4,8}\s*(?:is your (?:otp|verification code|secret pin))\b""", RegexOption.IGNORE_CASE),
        Regex("""\bdo not share this (?:code|otp|pin) with anyone\b""", RegexOption.IGNORE_CASE)
    )

    private val financialRegexList = listOf(
        Regex("""\b(?:debited|credited|transferred|withdrawn|refunded)\b""", RegexOption.IGNORE_CASE),
        Regex("""\b(?:inr|rs\.?|usd|\$|eur|₹)\s*[\d,]+(?:\.\d{2})?\b""", RegexOption.IGNORE_CASE),
        Regex("""\b(?:a/c|account)\s*(?:no\.?|ending)?\s*(?:x+|\*+)?\d{3,4}\b""", RegexOption.IGNORE_CASE),
        Regex("""\b(?:upi|neft|rtgs|imps|atm|pos txn)\b""", RegexOption.IGNORE_CASE),
        Regex("""\b(?:available balance|bal is|current bal)\b""", RegexOption.IGNORE_CASE)
    )

    data class FilterResult(
        val isSensitive: Boolean,
        val reason: String? = null
    )

    fun evaluate(text: String): FilterResult {
        if (text.isBlank()) return FilterResult(isSensitive = false)

        for (regex in otpRegexList) {
            if (regex.containsMatchIn(text)) {
                return FilterResult(
                    isSensitive = true,
                    reason = "Verification code or OTP detected"
                )
            }
        }

        for (regex in financialRegexList) {
            if (regex.containsMatchIn(text)) {
                return FilterResult(
                    isSensitive = true,
                    reason = "Banking transaction or financial alert detected"
                )
            }
        }

        return FilterResult(isSensitive = false)
    }
}
