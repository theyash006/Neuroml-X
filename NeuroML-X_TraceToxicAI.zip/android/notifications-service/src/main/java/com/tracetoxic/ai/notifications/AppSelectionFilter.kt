package com.tracetoxic.ai.notifications

import com.tracetoxic.ai.domain.repository.NotificationRepository

/**
 * Ensures notifications are strictly filtered against the user-monitored package whitelist.
 * Any unselected app is immediately dropped.
 */
class AppSelectionFilter(
    private val notificationRepository: NotificationRepository
) {
    suspend fun isAllowed(packageName: String): Boolean {
        // Only allow analysis if user explicitly selected this application
        return notificationRepository.isAppMonitored(packageName)
    }
}
