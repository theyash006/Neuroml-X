package com.tracetoxic.ai.notifications

import android.app.Notification
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.service.notification.StatusBarNotification
import com.tracetoxic.ai.core.model.NotificationEvent
import java.util.UUID

/**
 * Extracts structured notification metadata (sender, text content, application name)
 * from a StatusBarNotification.
 */
class NotificationParser(private val context: Context) {

    fun parse(sbn: StatusBarNotification): NotificationEvent? {
        val notification = sbn.notification ?: return null
        val extras: Bundle = notification.extras ?: return null
        val packageName = sbn.packageName

        // Extract title (usually sender name in chat apps)
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: "Unknown"

        // Extract body text
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim()
            ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim()

        if (text.isNullOrBlank()) {
            return null // No text payload to evaluate
        }

        val appDisplayName = try {
            val pm = context.packageManager
            val appInfo = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(appInfo).toString()
        } catch (e: PackageManager.NameNotFoundException) {
            packageName
        }

        return NotificationEvent(
            eventId = UUID.randomUUID().toString(),
            packageName = packageName,
            appDisplayName = appDisplayName,
            sender = title,
            text = text,
            postTime = sbn.postTime
        )
    }
}
