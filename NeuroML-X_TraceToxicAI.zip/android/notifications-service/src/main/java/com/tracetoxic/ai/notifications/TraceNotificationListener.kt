package com.tracetoxic.ai.notifications

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.tracetoxic.ai.domain.usecase.AnalyzeNotificationUseCase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Android NotificationListenerService implementation for TraceToxicAI.
 * Intercepts notifications, applies strict user whitelist & privacy filtering,
 * and delegates clean communication text to AnalyzeNotificationUseCase.
 */
class TraceNotificationListener : NotificationListenerService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    
    // In production, injected via Hilt
    lateinit var parser: NotificationParser
    lateinit var appFilter: AppSelectionFilter
    lateinit var sensitiveFilter: SensitiveDataFilter
    lateinit var analyzeUseCase: AnalyzeNotificationUseCase

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "TraceNotificationListener started.")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return

        serviceScope.launch {
            try {
                val pkg = sbn.packageName

                // Filter 1: Check user app whitelist
                if (!::appFilter.isInitialized || !appFilter.isAllowed(pkg)) {
                    return@launch
                }

                // Filter 2: Extract text payload
                if (!::parser.isInitialized) return@launch
                val event = parser.parse(sbn) ?: return@launch

                // Filter 3: Check sensitive non-message data (OTPs, banking)
                if (::sensitiveFilter.isInitialized) {
                    val sensResult = sensitiveFilter.evaluate(event.text)
                    if (sensResult.isSensitive) {
                        Log.d(TAG, "Notification dropped due to sensitive data: ${sensResult.reason}")
                        return@launch
                    }
                }

                // Execute analysis pipeline
                if (::analyzeUseCase.isInitialized) {
                    analyzeUseCase(event)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error processing notification", e)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        Log.i(TAG, "TraceNotificationListener stopped.")
    }

    companion object {
        private const val TAG = "TraceNotifListener"
    }
}
