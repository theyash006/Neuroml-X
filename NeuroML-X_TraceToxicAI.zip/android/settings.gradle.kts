pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "TraceToxicAI"

include(":app")
include(":core:model")
include(":core:security")
include(":domain")
include(":notifications-service")
include(":detection-engine")
include(":risk-engine")
include(":feature-auth")
include(":feature-onboarding")
include(":reporting")
