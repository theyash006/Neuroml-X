package com.tracetoxic.ai.engine

import com.tracetoxic.ai.core.model.DetectionInput
import com.tracetoxic.ai.core.model.DetectionResult
import com.tracetoxic.ai.domain.engine.DetectionEngine

/**
 * Hybrid Detection Engine:
 * Attempts cloud analysis when opted-in by user; automatically falls back
 * seamlessly to on-device engine if network is disconnected or server is unavailable.
 */
class HybridDetectionEngine(
    private val allowCloud: Boolean = false,
    private val onDeviceEngine: OnDeviceDetectionEngine = OnDeviceDetectionEngine(),
    private val cloudEngine: DetectionEngine? = null
) : DetectionEngine {

    override suspend fun analyze(input: DetectionInput): DetectionResult {
        if (!allowCloud || cloudEngine == null) {
            return onDeviceEngine.analyze(input)
        }

        return try {
            cloudEngine.analyze(input)
        } catch (e: Exception) {
            // Automatic Fallback to OnDevice
            val fallbackResult = onDeviceEngine.analyze(input)
            val updatedExplanations = fallbackResult.explanations +
                "[Fallback Notice: Cloud engine unavailable (${e.localizedMessage}). Processed on-device.]"
            fallbackResult.copy(
                explanations = updatedExplanations,
                engineUsed = "Hybrid (Fallback to OnDevice)"
            )
        }
    }
}
