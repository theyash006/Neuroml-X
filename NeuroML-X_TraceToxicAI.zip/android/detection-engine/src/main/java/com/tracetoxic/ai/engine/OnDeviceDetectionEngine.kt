package com.tracetoxic.ai.engine

import com.tracetoxic.ai.core.model.BullyingCategory
import com.tracetoxic.ai.core.model.DetectionInput
import com.tracetoxic.ai.core.model.DetectionResult
import com.tracetoxic.ai.domain.engine.DetectionEngine

/**
 * On-device local NLP classifier.
 * Formulated to run efficiently on mobile hardware (e.g. TFLite / ONNX Runtime).
 */
class OnDeviceDetectionEngine : DetectionEngine {

    private val modelVersion = "TraceToxic-DistilMulti-v1.4-Mobile"

    // Threat patterns
    private val threatKeywords = listOf(
        "kill you", "beat you", "break your neck", "end your life", "you're dead",
        "watch your back", "find where you live", "gonna hurt you",
        "जान से मार दूंगा", "तुझे खत्म कर दूंगा", "तेरे टुकड़े करूंगा", "घर आके मारूंगा", "बच के रहना",
        "jaan se maar doonga", "marunga tujhe", "khatam kar dunga", "bach ke rehna",
        "ਤੈਨੂੰ ਜਾਨੋਂ ਮਾਰ ਦਿਆਂਗਾ", "ਤੇਰਾ ਕਤਲ ਕਰਾਂਗਾ", "ਘਰ ਆ ਕੇ ਕੁੱਟਾਂਗਾ", "tainu maar deyange"
    )

    // Insults and harassment
    private val insultKeywords = listOf(
        "loser", "idiot", "moron", "ugly", "worthless", "disgusting", "pathetic",
        "freak", "stupid", "dumbass", "creep", "kill yourself",
        "गधा", "कमीने", "बकवास", "बेवकूफ", "घटिया",
        "kutta", "kameena", "ghatiya", "bewakoof",
        "ਬੇਵਕੂਫ਼", "ਘਟੀਆ", "ਕੁੱਤਾ"
    )

    override suspend fun analyze(input: DetectionInput): DetectionResult {
        val text = input.messageText.lowercase()
        val explanations = mutableListOf<String>()

        // Check for threats
        val threatFound = threatKeywords.any { text.contains(it) }
        if (threatFound) {
            explanations.add("Explicit physical or bodily harm threats identified")
            return DetectionResult(
                toxicityScore = 0.88f,
                threatScore = 0.90f,
                category = BullyingCategory.THREAT,
                confidence = 0.94f,
                explanations = explanations,
                modelVersion = modelVersion,
                engineUsed = "OnDevice"
            )
        }

        // Check for insults / cyberbullying
        val matchedInsults = insultKeywords.filter { text.contains(it) }
        if (matchedInsults.isNotEmpty()) {
            val isSevere = matchedInsults.size >= 2 || text.contains("kill yourself")
            val cat = if (isSevere) BullyingCategory.CYBERBULLYING else BullyingCategory.VERBAL_BULLYING
            explanations.add("Targeted derogatory language and hostile remarks identified")
            return DetectionResult(
                toxicityScore = if (isSevere) 0.82f else 0.58f,
                threatScore = if (text.contains("kill yourself")) 0.40f else 0.12f,
                category = cat,
                confidence = 0.88f,
                explanations = explanations,
                modelVersion = modelVersion,
                engineUsed = "OnDevice"
            )
        }

        // Normal text
        explanations.add("No harmful communication patterns detected")
        return DetectionResult(
            toxicityScore = 0.05f,
            threatScore = 0.01f,
            category = BullyingCategory.NORMAL,
            confidence = 0.95f,
            explanations = explanations,
            modelVersion = modelVersion,
            engineUsed = "OnDevice"
        )
    }
}
