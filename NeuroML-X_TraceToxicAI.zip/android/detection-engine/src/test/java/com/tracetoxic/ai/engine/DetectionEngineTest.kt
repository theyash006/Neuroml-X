package com.tracetoxic.ai.engine

import com.tracetoxic.ai.core.model.BullyingCategory
import com.tracetoxic.ai.core.model.DetectionInput
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class DetectionEngineTest {

    private lateinit var engine: OnDeviceDetectionEngine

    @Before
    fun setUp() {
        engine = OnDeviceDetectionEngine()
    }

    @Test
    fun analyze_threatMessage_classifiesAsThreat() = runBlocking {
        val input = DetectionInput(
            messageText = "I will find where you live and beat you",
            senderId = "stalker",
            appSource = "Instagram",
            timestamp = System.currentTimeMillis()
        )

        val result = engine.analyze(input)
        assertEquals(BullyingCategory.THREAT, result.category)
        assertTrue(result.threatScore >= 0.80f)
        assertTrue(result.explanations.isNotEmpty())
    }

    @Test
    fun analyze_hindiThreatMessage_detectsHarm() = runBlocking {
        val input = DetectionInput(
            messageText = "तुझे जान से मार दूंगा",
            senderId = "hindi_sender",
            appSource = "WhatsApp",
            timestamp = System.currentTimeMillis()
        )

        val result = engine.analyze(input)
        assertEquals(BullyingCategory.THREAT, result.category)
    }

    @Test
    fun analyze_cleanMessage_classifiesAsNormal() = runBlocking {
        val input = DetectionInput(
            messageText = "Are we still doing homework together tonight?",
            senderId = "friend",
            appSource = "Discord",
            timestamp = System.currentTimeMillis()
        )

        val result = engine.analyze(input)
        assertEquals(BullyingCategory.NORMAL, result.category)
        assertTrue(result.toxicityScore < 0.15f)
    }
}
