package com.tracetoxic.ai.domain.repository

import com.tracetoxic.ai.core.model.NotificationEvent
import kotlinx.coroutines.flow.Flow

interface NotificationRepository {
    fun getMonitoredPackages(): Flow<Set<String>>
    suspend fun setMonitoredPackages(packages: Set<String>)
    suspend fun isAppMonitored(packageName: String): Boolean
    fun observeIncomingEvents(): Flow<NotificationEvent>
    suspend fun emitNotificationEvent(event: NotificationEvent)
}
