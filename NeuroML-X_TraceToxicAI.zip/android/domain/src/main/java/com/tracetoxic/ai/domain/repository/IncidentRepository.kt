package com.tracetoxic.ai.domain.repository

import com.tracetoxic.ai.core.model.Incident
import com.tracetoxic.ai.core.model.ReviewStatus
import com.tracetoxic.ai.core.model.UserFeedback
import kotlinx.coroutines.flow.Flow

interface IncidentRepository {
    fun getAllIncidents(): Flow<List<Incident>>
    fun getPendingIncidents(): Flow<List<Incident>>
    fun getVaultIncidents(): Flow<List<Incident>>
    suspend fun saveIncident(incident: Incident)
    suspend fun updateReviewStatus(incidentId: String, status: ReviewStatus, feedback: UserFeedback? = null)
    suspend fun deleteIncident(incidentId: String)
    suspend fun purgeOlderThan(timestampCutoff: Long)
}
