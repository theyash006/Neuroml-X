package com.tracetoxic.ai.domain.risk

import com.tracetoxic.ai.core.model.BullyingCategory
import com.tracetoxic.ai.core.model.Incident
import com.tracetoxic.ai.core.model.RiskLevel

data class RiskEvaluation(
    val score: Int,
    val level: RiskLevel,
    val patterns: List<String>
)

interface RiskCalculator {
    suspend fun calculateRisk(
        toxicityScore: Float,
        threatScore: Float,
        category: BullyingCategory,
        senderId: String,
        recentHistory: List<Incident>
    ): RiskEvaluation
}
