package com.tracetoxic.ai.domain.usecase

import com.tracetoxic.ai.core.model.BullyingCategory
import com.tracetoxic.ai.core.model.DetectionInput
import com.tracetoxic.ai.core.model.DetectionResult
import com.tracetoxic.ai.core.model.Incident
import com.tracetoxic.ai.core.model.NotificationEvent
import com.tracetoxic.ai.core.model.ReviewStatus
import com.tracetoxic.ai.domain.engine.DetectionEngine
import com.tracetoxic.ai.domain.repository.IncidentRepository
import com.tracetoxic.ai.domain.risk.RiskCalculator
import kotlinx.coroutines.flow.first
import java.util.UUID

class AnalyzeNotificationUseCase(
    private val detectionEngine: DetectionEngine,
    private val riskCalculator: RiskCalculator,
    private val incidentRepository: IncidentRepository
) {
    suspend operator fun invoke(event: NotificationEvent): Incident? {
        val input = DetectionInput(
            messageText = event.text,
            senderId = event.sender,
            appSource = event.appDisplayName,
            timestamp = event.postTime
        )

        // Step 1: Run through Detection Engine (OnDevice/Cloud/Hybrid)
        val detectionResult: DetectionResult = detectionEngine.analyze(input)

        // If normal communication, do not escalate to an incident
        if (detectionResult.category == BullyingCategory.NORMAL) {
            return null
        }

        // Step 2: Fetch history for pattern and repetition analysis
        val history = incidentRepository.getAllIncidents().first()

        // Step 3: Compute risk score and evaluate repetition/multi-sender patterns
        val riskEval = riskCalculator.calculateRisk(
            toxicityScore = detectionResult.toxicityScore,
            threatScore = detectionResult.threatScore,
            category = detectionResult.category,
            senderId = event.sender,
            recentHistory = history
        )

        // Step 4: Construct Incident Record
        val incident = Incident(
            incidentId = "INC-${UUID.randomUUID().toString().take(8).uppercase()}",
            timestamp = event.postTime,
            appSource = event.appDisplayName,
            senderId = event.sender,
            messageText = event.text,
            category = detectionResult.category,
            toxicityScore = detectionResult.toxicityScore,
            threatScore = detectionResult.threatScore,
            confidence = detectionResult.confidence,
            riskScore = riskEval.score,
            riskLevel = riskEval.level,
            explanations = detectionResult.explanations,
            detectedPatterns = riskEval.patterns,
            reviewStatus = ReviewStatus.PENDING
        )

        // Step 5: Save to repository for human review
        incidentRepository.saveIncident(incident)
        return incident
    }
}
