package com.tracetoxic.ai.domain.engine

import com.tracetoxic.ai.core.model.DetectionInput
import com.tracetoxic.ai.core.model.DetectionResult

/**
 * Common abstraction for all AI detection engines (OnDevice, Cloud, Hybrid).
 */
interface DetectionEngine {
    suspend fun analyze(input: DetectionInput): DetectionResult
}
