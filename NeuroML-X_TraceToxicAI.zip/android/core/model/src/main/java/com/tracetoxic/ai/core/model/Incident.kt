package com.tracetoxic.ai.core.model

/**
 * Normalized notification extracted from Android's NotificationListenerService
 * after passing AppSelectionFilter and SensitiveDataFilter.
 */
data class NotificationEvent(
    val eventId: String,
    val packageName: String,
    val appDisplayName: String,
    val sender: String,
    val text: String,
    val postTime: Long
)

/**
 * Verified or pending incident preserved in the encrypted evidence vault.
 */
data class Incident(
    val incidentId: String,
    val timestamp: Long,
    val appSource: String,
    val senderId: String,
    val messageText: String,
    val category: BullyingCategory,
    val toxicityScore: Float,
    val threatScore: Float,
    val confidence: Float,
    val riskScore: Int,
    val riskLevel: RiskLevel,
    val explanations: List<String>,
    val detectedPatterns: List<String> = emptyList(),
    val reviewStatus: ReviewStatus = ReviewStatus.PENDING,
    val userFeedback: UserFeedback? = null
)

enum class ReviewStatus {
    PENDING,
    SAVED_VAULT,
    DISMISSED
}

data class UserFeedback(
    val isAccurate: Boolean,
    val reasonCategory: String?,
    val timestamp: Long
)

/**
 * Age-based operation modes.
 */
enum class AgeMode {
    MINOR, // Under 18: optional guardian connection, enhanced educational safety
    ADULT  // 18+: self-advocacy, trusted contacts, direct legal reporting
}
