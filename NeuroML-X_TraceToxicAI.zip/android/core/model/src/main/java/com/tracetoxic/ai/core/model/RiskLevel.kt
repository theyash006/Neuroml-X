package com.tracetoxic.ai.core.model

/**
 * Objective risk levels computed by the Risk Engine (0-100 scale).
 * Calibrated to reserve severe alert styling solely for HIGH and CRITICAL.
 */
enum class RiskLevel(val minScore: Int, val maxScore: Int, val description: String) {
    LOW(0, 25, "Minimal or standard communication noise"),
    MODERATE(26, 50, "Noticeable toxicity or initial hostility detected"),
    HIGH(51, 75, "Severe harassment, repeated patterns, or clear threats"),
    CRITICAL(76, 100, "Imminent bodily threats, severe coercion, or extreme escalation");

    companion object {
        fun fromScore(score: Int): RiskLevel {
            return when (score) {
                in 0..25 -> LOW
                in 26..50 -> MODERATE
                in 51..75 -> HIGH
                else -> CRITICAL
            }
        }
    }
}
