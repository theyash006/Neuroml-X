package com.tracetoxic.ai.core.model

/**
 * Categories of cyberbullying and online harm recognized by the TraceToxicAI NLP engine.
 * Language is carefully structured to avoid definitive legal accusations.
 */
enum class BullyingCategory(val displayName: String, val advisoryLabel: String) {
    NORMAL(
        displayName = "Normal Communication",
        advisoryLabel = "No harmful language identified"
    ),
    VERBAL_BULLYING(
        displayName = "Verbal Harassment",
        advisoryLabel = "Potential verbal insult or hostile remark detected"
    ),
    CYBERBULLYING(
        displayName = "Cyberbullying Pattern",
        advisoryLabel = "Language indicates targeted negative behavior"
    ),
    THREAT(
        displayName = "Physical Threat",
        advisoryLabel = "Potential threat to personal or physical safety detected"
    ),
    GROUP_HARASSMENT(
        displayName = "Group / Coordinated Harassment",
        advisoryLabel = "Potential coordinated multi-sender activity detected"
    ),
    BLACKMAIL(
        displayName = "Coercion / Blackmail",
        advisoryLabel = "Potential extortion or unauthorized disclosure language detected"
    ),
    SOCIAL_EXCLUSION(
        displayName = "Social Exclusion",
        advisoryLabel = "Language indicates deliberate group isolation or ostracization"
    ),
    SEXUAL_HARASSMENT(
        displayName = "Sexual Harassment",
        advisoryLabel = "Unsolicited or inappropriate sexually explicit language detected"
    ),
    TOXIC_LANGUAGE(
        displayName = "Toxic Language",
        advisoryLabel = "Degrading or offensive speech patterns detected"
    )
}
