package com.tracetoxic.ai.core.model

/**
 * Standardized input passed into any DetectionEngine implementation.
 */
data class DetectionInput(
    val messageText: String,
    val senderId: String,
    val appSource: String,
    val timestamp: Long,
    val language: String? = null,
    val conversationContext: List<String> = emptyList()
)

/**
 * Standardized output produced by any DetectionEngine implementation.
 */
data class DetectionResult(
    val toxicityScore: Float, // 0.0f .. 1.0f
    val threatScore: Float,   // 0.0f .. 1.0f
    val category: BullyingCategory,
    val confidence: Float,    // 0.0f .. 1.0f
    val explanations: List<String>,
    val modelVersion: String,
    val detectedLanguage: String = "English",
    val engineUsed: String = "OnDevice"
)
