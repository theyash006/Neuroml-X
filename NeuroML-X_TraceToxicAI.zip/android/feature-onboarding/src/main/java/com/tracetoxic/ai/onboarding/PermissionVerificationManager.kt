package com.tracetoxic.ai.onboarding

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import com.tracetoxic.ai.notifications.TraceNotificationListener

/**
 * Manages runtime verification of NotificationListenerService permission.
 * Always checks actual system setting on app launch, resume, and return from settings.
 */
class PermissionVerificationManager(private val context: Context) {

    /**
     * Re-checks actual system state directly from NotificationManagerCompat.
     * Never relies on stale or cached boolean flags.
     */
    fun isNotificationAccessGranted(): Boolean {
        val enabledPackages = NotificationManagerCompat.getEnabledListenerPackages(context)
        val myPackageName = context.packageName
        return enabledPackages.contains(myPackageName)
    }

    /**
     * Generates explicit Intent to Android system's Notification Listener settings screen.
     */
    fun createOpenSettingsIntent(): Intent {
        val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return intent
    }
}
