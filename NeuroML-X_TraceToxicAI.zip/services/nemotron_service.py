"""
NVIDIA Nemotron Agentic Service via Nebius Token Factory for NEUROML-X.
Provides contextual reasoning, intent interpretation, conversation escalation tracking,
explainable AI signal generation, and safe response intervention advice.

Integrates using OpenAI-compatible API client via Nebius Token Factory:
Endpoint: https://api.studio.nebius.ai/v1
Model: nvidia/Llama-3.1-Nemotron-70B-Instruct-HF (or configured via NEMOTRON_MODEL)
"""

import os
import json
import logging
from typing import Dict, Any, List, Optional
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)

DEFAULT_NEBIUS_BASE_URL = "https://api.studio.nebius.ai/v1"
DEFAULT_NEMOTRON_MODEL = "nvidia/Llama-3.1-Nemotron-70B-Instruct-HF"

class NemotronAgentService:
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        model_name: Optional[str] = None
    ):
        self.api_key = api_key or os.getenv("NEBIUS_API_KEY", "").strip()
        self.base_url = base_url or os.getenv("NEBIUS_BASE_URL", DEFAULT_NEBIUS_BASE_URL).strip()
        self.model_name = model_name or os.getenv("NEMOTRON_MODEL", DEFAULT_NEMOTRON_MODEL).strip()
        self._client = None
        self._init_client()

    def _init_client(self):
        if self.api_key:
            try:
                from openai import OpenAI
                self._client = OpenAI(
                    base_url=self.base_url,
                    api_key=self.api_key,
                    timeout=15.0
                )
            except Exception as e:
                logger.warning(f"Failed to initialize OpenAI client for Nebius: {e}")
                self._client = None

    @property
    def is_available(self) -> bool:
        """Returns True if a valid API key is present and client initialized."""
        return bool(self._client and self.api_key)

    def analyze_single_message(
        self,
        text: str,
        ml_scores: Dict[str, float],
        top_emotion: str,
        emotion_confidence: float,
        detected_categories: List[str]
    ) -> Dict[str, Any]:
        """
        Agentic reasoning on a single message.
        Takes ML probability distributions and interprets context, intent, and safe intervention.
        """
        if not text.strip():
            return self._empty_response()

        if not self.is_available:
            return self._fallback_single_reasoning(
                text, ml_scores, top_emotion, detected_categories,
                reason="Nebius Token Factory API key not configured or offline."
            )

        system_prompt = (
            "You are the NeuroML-X Safety Agent powered by NVIDIA Nemotron on Nebius Token Factory. "
            "Your role is to reason over an incoming message combined with first-pass Machine Learning toxicity scores. "
            "Do NOT blindly label benign text as toxic. Understand context, nuance, sarcasm, and intent. "
            "Do NOT provide medical or psychiatric diagnoses. "
            "You MUST output valid JSON only, with the following exact keys:\n"
            "{\n"
            '  "classification": "SAFE" | "POSSIBLY TOXIC" | "TOXIC" | "CYBERBULLYING" | "SEVERE HARASSMENT",\n'
            '  "context_intent": "Summary of sender intent and emotional tone",\n'
            '  "detected_signals": ["Signal 1", "Signal 2"],\n'
            '  "explanation": "Clear, objective explanation of why this was or was not flagged",\n'
            '  "recommended_action": "Safe, non-retaliatory protective intervention recommendation",\n'
            '  "safe_victim_response": "De-escalating or assertive boundary message the victim could choose to send",\n'
            '  "nemotron_confidence": 0.0 to 1.0\n'
            "}"
        )

        user_content = (
            f"Message Content: \"{text}\"\n\n"
            f"First-Pass ML Toxicity Probabilities:\n"
            f"{json.dumps(ml_scores, indent=2)}\n\n"
            f"Primary Emotion: {top_emotion} ({emotion_confidence * 100:.1f}% confidence)\n"
            f"Flagged Categories: {', '.join(detected_categories)}\n\n"
            "Analyze the above message and provide your structured contextual reasoning in JSON."
        )

        try:
            response = self._client.chat.completions.create(
                model=self.model_name,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_content}
                ],
                temperature=0.2,
                max_tokens=600,
                response_format={"type": "json_object"}
            )
            raw_json = response.choices[0].message.content.strip()
            result = json.loads(raw_json)
            result["engine"] = f"NVIDIA Nemotron via Nebius Token Factory ({self.model_name})"
            result["is_fallback"] = False
            return result
        except Exception as e:
            logger.error(f"Nemotron API error: {e}")
            return self._fallback_single_reasoning(
                text, ml_scores, top_emotion, detected_categories,
                reason=f"Nebius API connection error ({type(e).__name__}). Seamlessly using local agent reasoning."
            )

    def analyze_conversation(
        self,
        turns: List[Dict[str, str]],
        ml_turn_scores: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Analyzes a multi-turn conversation between two or more participants.
        Identifies repeated targeting, escalation trends, harassment, and mobbing.
        """
        if not turns:
            return {
                "overall_classification": "SAFE",
                "escalation_detected": False,
                "repeated_targeting": False,
                "summary": "No conversation turns provided.",
                "timeline_analysis": [],
                "recommended_intervention": "None required.",
                "is_fallback": False,
                "engine": "Local"
            }

        if not self.is_available:
            return self._fallback_conversation_reasoning(turns, ml_turn_scores)

        system_prompt = (
            "You are the NeuroML-X Conversation Safety Agent powered by NVIDIA Nemotron on Nebius Token Factory. "
            "Analyze a multi-turn dialogue between users to evaluate relational dynamics, harassment escalation, "
            "and repeated targeting. Output strictly valid JSON with keys:\n"
            "{\n"
            '  "overall_classification": "SAFE" | "POSSIBLY TOXIC" | "TOXIC" | "CYBERBULLYING" | "SEVERE HARASSMENT",\n'
            '  "escalation_detected": true | false,\n'
            '  "repeated_targeting": true | false,\n'
            '  "targeted_user": "Name of user being harassed or null",\n'
            '  "primary_aggressor": "Name of user initiating hostility or null",\n'
            '  "summary": "Concise summary of conversation trajectory",\n'
            '  "escalation_details": "Explanation of how aggression evolved across turns",\n'
            '  "recommended_intervention": "Clear moderation or safety action"\n'
            "}"
        )

        formatted_turns = []
        for i, (turn, ml_info) in enumerate(zip(turns, ml_turn_scores)):
            formatted_turns.append(
                f"Turn {i+1} [{turn.get('speaker', 'User')}]: \"{turn.get('text', '')}\" "
                f"(ML Toxicity: {ml_info.get('peak_toxicity', 0):.1f}%, Emotion: {ml_info.get('top_emotion', 'neutral')})"
            )

        user_content = "Conversation Transcript:\n" + "\n".join(formatted_turns)

        try:
            response = self._client.chat.completions.create(
                model=self.model_name,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_content}
                ],
                temperature=0.2,
                max_tokens=800,
                response_format={"type": "json_object"}
            )
            raw_json = response.choices[0].message.content.strip()
            result = json.loads(raw_json)
            result["engine"] = f"NVIDIA Nemotron via Nebius Token Factory ({self.model_name})"
            result["is_fallback"] = False
            return result
        except Exception as e:
            logger.error(f"Nemotron conversation API error: {e}")
            return self._fallback_conversation_reasoning(turns, ml_turn_scores)

    def _fallback_single_reasoning(
        self,
        text: str,
        ml_scores: Dict[str, float],
        top_emotion: str,
        detected_categories: List[str],
        reason: str
    ) -> Dict[str, Any]:
        """Local deterministic agent reasoning when remote Nemotron is unavailable."""
        peak_tox = max(ml_scores.values()) if ml_scores else 0.0
        threat = ml_scores.get("threat", 0.0)
        insult = ml_scores.get("insult", 0.0)
        hate = ml_scores.get("identity_hate", 0.0)

        signals = []
        if threat >= 40:
            signals.append("Physical threat or intimidation language")
        if insult >= 45:
            signals.append("Direct targeted personal insult")
        if hate >= 35:
            signals.append("Identity-based derogatory slur")
        if top_emotion in ["anger", "disgust"] and peak_tox >= 40:
            signals.append(f"Elevated hostile emotional affect ({top_emotion})")

        if threat >= 65 or (peak_tox >= 80 and "Direct Physical Threat" in detected_categories):
            classification = "SEVERE HARASSMENT"
            action = "Immediate evidence preservation, block sender across platforms, and report to emergency authorities or school administration."
            resp = "Do not contact me again. Your messages have been documented and reported."
        elif peak_tox >= 60 or "Severe Harassment" in detected_categories:
            classification = "CYBERBULLYING"
            action = "Set boundaries, mute/block the account, and document harassment history."
            resp = "I do not accept being spoken to this way. Stop contacting me."
        elif peak_tox >= 35:
            classification = "TOXIC"
            action = "Disengage from hostile interaction and monitor further communications."
            resp = "Let's keep this conversation civil or discontinue speaking."
        elif peak_tox >= 20:
            classification = "POSSIBLY TOXIC"
            action = "Clarify intent; language displays mild hostility or sarcasm."
            resp = "I am not sure what you mean by that, but let's stay constructive."
        else:
            classification = "SAFE"
            action = "No intervention required. Content is safe and civil."
            resp = "Thank you for the constructive message!"

        explanation = (
            f"The ML classifier scored peak toxicity at {peak_tox:.1f}% ({max(ml_scores, key=ml_scores.get) if ml_scores else 'benign'}). "
            f"Context shows {top_emotion} tone with {len(signals)} hostile signal markers."
        )

        return {
            "classification": classification,
            "context_intent": f"Tone is {top_emotion} with {'aggressive' if peak_tox >= 50 else 'benign'} interpersonal framing.",
            "detected_signals": signals or ["Benign communication markers"],
            "explanation": explanation,
            "recommended_action": action,
            "safe_victim_response": resp,
            "nemotron_confidence": round(min(0.98, max(0.65, peak_tox / 100)), 2),
            "engine": "Local Agent Engine (Offline Fallback)",
            "is_fallback": True,
            "fallback_notice": reason
        }

    def _fallback_conversation_reasoning(
        self,
        turns: List[Dict[str, str]],
        ml_turn_scores: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Local multi-turn escalation analyzer when Nemotron API is unavailable."""
        toxic_scores = [t.get("peak_toxicity", 0.0) for t in ml_turn_scores]
        max_tox = max(toxic_scores) if toxic_scores else 0.0
        escalation = False

        if len(toxic_scores) >= 2:
            if toxic_scores[-1] > toxic_scores[0] + 25.0:
                escalation = True

        speakers = [t.get("speaker", "User") for t in turns]
        repeated_targeting = len(speakers) != len(set(speakers)) and max_tox >= 50

        if max_tox >= 75:
            classification = "SEVERE HARASSMENT"
        elif max_tox >= 50 or repeated_targeting:
            classification = "CYBERBULLYING"
        elif max_tox >= 30:
            classification = "TOXIC"
        else:
            classification = "SAFE"

        return {
            "overall_classification": classification,
            "escalation_detected": escalation,
            "repeated_targeting": repeated_targeting,
            "targeted_user": turns[-1].get("speaker") if len(turns) > 1 else None,
            "primary_aggressor": turns[0].get("speaker") if max_tox >= 40 else None,
            "summary": f"Analyzed {len(turns)} dialogue turns. Peak toxicity reached {max_tox:.1f}%.",
            "escalation_details": "Toxicity escalated across dialogue turns." if escalation else "Hostility levels remained steady or benign.",
            "recommended_intervention": "Intervene and separate participants." if max_tox >= 50 else "Continue normal conversation.",
            "engine": "Local Agent Engine (Offline Fallback)",
            "is_fallback": True
        }

    def _empty_response(self) -> Dict[str, Any]:
        return {
            "classification": "SAFE",
            "context_intent": "Empty or whitespace input.",
            "detected_signals": [],
            "explanation": "No text provided to evaluate.",
            "recommended_action": "Enter content to begin safety assessment.",
            "safe_victim_response": "",
            "nemotron_confidence": 1.0,
            "engine": "None",
            "is_fallback": False
        }
