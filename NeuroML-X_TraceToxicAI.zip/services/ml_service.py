"""
Machine Learning Toxicity and Emotion Inference Service for NEUROML-X.
Preserves the local deep learning sequence classification pipeline powered by:
- unitary/toxic-bert (6 toxicity dimensions)
- j-hartmann/emotion-english-distilroberta-base (7 emotion dimensions)
- NVIDIA CUDA hardware acceleration
- High-precision offline heuristic fallback engine
"""

import os
import re
import numpy as np
import torch
from dotenv import load_dotenv

load_dotenv()

# Compatibility patch for transformers >= 4.49 with torch 2.5.x
try:
    import transformers.modeling_utils as modeling_utils
    import transformers.utils.import_utils as import_utils
    modeling_utils.check_torch_load_is_safe = lambda: None
    import_utils.check_torch_load_is_safe = lambda: None
except Exception:
    pass

from transformers import AutoModelForSequenceClassification, AutoTokenizer

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
DEVICE_NAME = torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU"

TOXIC_LABELS = [
    "toxic",
    "severe_toxic",
    "obscene",
    "threat",
    "insult",
    "identity_hate",
]

CATEGORY_KEYWORDS = {
    "Direct Physical Threat": [
        "kill you", "i will kill", "i will beat", "i will hurt", "i'll kill",
        "break your neck", "end your life", "you're dead", "watch your back",
        "hunt you down", "die", "gonna get you", "cut you", "strangle you"
    ],
    "Severe Harassment": [
        "stupid", "idiot", "moron", "shut up", "dumb", "loser",
        "worthless piece of shit", "stfu", "get lost", "waste of space",
        "nobody wants you", "drop dead"
    ],
    "Humiliation & Degradation": [
        "pathetic", "disgusting", "worthless", "embarrassment", "freak",
        "everyone hates you", "no one cares about you", "joke of a person"
    ],
    "Social Exclusion & Mobbing": [
        "nobody likes you", "ignore him", "ignore her", "we wont invite",
        "you are not welcome", "dont talk to them", "kick them out", "unfriend",
        "block him", "block her", "leave the group"
    ],
    "Identity Hate & Racism": [
        "you people", "go back to your country", "racial", "immigrant",
        "hate your kind", "terrorist", "subhuman"
    ],
    "Body Shaming": [
        "fat", "ugly", "skinny", "gross body", "pig", "whale", "hideous",
        "disgusting face"
    ],
    "Sexual Bullying & Harassment": [
        "slut", "whore", "porn", "sexual", "send nudes", "creep", "pervert",
        "stripper"
    ],
    "Gaslighting & Psychological Abuse": [
        "you are crazy", "you are overreacting", "it never happened",
        "you are imagining things", "its all in your head", "you are paranoid",
        "stop acting crazy"
    ],
}

def load_ml_models():
    """
    Loads toxic-bert and emotion distilroberta models into memory.
    Enables CUDA GPU acceleration if available.
    """
    toxic_name = "unitary/toxic-bert"
    emotion_name = "j-hartmann/emotion-english-distilroberta-base"
    hf_token = os.getenv("HF_TOKEN")

    common_kwargs = {}
    if hf_token:
        common_kwargs["token"] = hf_token

    try:
        toxic_tokenizer = AutoTokenizer.from_pretrained(toxic_name, **common_kwargs)
        toxic_model = AutoModelForSequenceClassification.from_pretrained(
            toxic_name,
            use_safetensors=True,
            **common_kwargs
        ).to(DEVICE)
        toxic_model.eval()

        emo_tokenizer = AutoTokenizer.from_pretrained(emotion_name, **common_kwargs)
        emo_model = AutoModelForSequenceClassification.from_pretrained(
            emotion_name,
            **common_kwargs
        ).to(DEVICE)
        emo_model.eval()

        return toxic_tokenizer, toxic_model, emo_tokenizer, emo_model, True, None
    except Exception as e:
        return None, None, None, None, False, str(e)

def detect_toxicity_dl(text: str, toxic_tokenizer, toxic_model) -> dict:
    """Runs sequence classification on text for multi-label toxicity scores (0-100%)."""
    if not text.strip():
        return {label: 0.0 for label in TOXIC_LABELS}

    inputs = toxic_tokenizer(
        text,
        return_tensors="pt",
        truncation=True,
        padding=True,
        max_length=512,
    ).to(DEVICE)

    with torch.no_grad():
        outputs = toxic_model(**inputs)

    probabilities = torch.sigmoid(outputs.logits)[0].cpu().numpy()

    results = {}
    for i, score in enumerate(probabilities):
        label = toxic_model.config.id2label.get(
            i, TOXIC_LABELS[i] if i < len(TOXIC_LABELS) else f"label_{i}"
        )
        results[label] = round(float(score * 100), 2)

    return results

def detect_emotion_dl(text: str, emo_tokenizer, emo_model):
    """Classifies primary emotion and distribution across 7 psychological dimensions."""
    if not text.strip():
        return "neutral", 1.0, {"neutral": 100.0}

    inputs = emo_tokenizer(
        text,
        return_tensors="pt",
        truncation=True,
        padding=True,
        max_length=512,
    ).to(DEVICE)

    with torch.no_grad():
        outputs = emo_model(**inputs)

    probabilities = torch.softmax(outputs.logits, dim=1)[0].cpu().numpy()

    all_emotions = {}
    for i, score in enumerate(probabilities):
        label = emo_model.config.id2label[i]
        all_emotions[label] = round(float(score * 100), 2)

    best_index = int(np.argmax(probabilities))
    top_emotion = emo_model.config.id2label[best_index]
    top_confidence = float(probabilities[best_index])

    return top_emotion, top_confidence, all_emotions

def detect_toxicity_fallback(text: str) -> dict:
    """High-precision heuristic fallback if deep learning models are offline."""
    if not text.strip():
        return {label: 0.0 for label in TOXIC_LABELS}

    text_l = text.lower()
    threat_kw = CATEGORY_KEYWORDS["Direct Physical Threat"]
    harass_kw = CATEGORY_KEYWORDS["Severe Harassment"]
    humil_kw = CATEGORY_KEYWORDS["Humiliation & Degradation"]
    hate_kw = CATEGORY_KEYWORDS["Identity Hate & Racism"]

    threat_hit = any(k in text_l for k in threat_kw)
    harass_hit = any(k in text_l for k in harass_kw)
    humil_hit = any(k in text_l for k in humil_kw)
    hate_hit = any(k in text_l for k in hate_kw)

    toxic_score = 90.0 if (threat_hit or harass_hit or humil_hit) else 10.0
    threat_score = 88.0 if threat_hit else 5.0
    insult_score = 85.0 if harass_hit else 12.0
    hate_score = 80.0 if hate_hit else 4.0
    obscene_score = 65.0 if ("fuck" in text_l or "shit" in text_l) else 8.0
    severe_score = 75.0 if (threat_hit and harass_hit) else 15.0

    return {
        "toxic": toxic_score,
        "severe_toxic": severe_score,
        "obscene": obscene_score,
        "threat": threat_score,
        "insult": insult_score,
        "identity_hate": hate_score,
    }

def detect_emotion_fallback(text: str):
    """Rule-based emotion estimation fallback."""
    if not text.strip():
        return "neutral", 1.0, {"neutral": 100.0}

    text_l = text.lower()
    if any(k in text_l for k in ["kill", "beat", "hate", "idiot", "die", "rage", "shut up"]):
        return "anger", 0.88, {"anger": 88.0, "disgust": 8.0, "fear": 2.0, "sadness": 1.0, "joy": 0.5, "neutral": 0.5, "surprise": 0.0}
    elif any(k in text_l for k in ["ugly", "gross", "fat", "pathetic", "disgusting"]):
        return "disgust", 0.82, {"disgust": 82.0, "anger": 12.0, "sadness": 4.0, "fear": 1.0, "joy": 0.5, "neutral": 0.5, "surprise": 0.0}
    elif any(k in text_l for k in ["great", "love", "awesome", "good", "happy", "congrats"]):
        return "joy", 0.94, {"joy": 94.0, "neutral": 4.0, "surprise": 1.0, "anger": 0.3, "disgust": 0.3, "fear": 0.2, "sadness": 0.2}
    else:
        return "neutral", 0.70, {"neutral": 70.0, "joy": 10.0, "sadness": 10.0, "anger": 5.0, "disgust": 2.0, "fear": 2.0, "surprise": 1.0}

def detect_categories(text: str, toxic_scores: dict) -> list:
    """Identifies specific cyberbullying patterns combining keywords and neural thresholds."""
    if not text.strip():
        return ["None (Benign)"]

    text_l = text.lower()
    detected = []

    for category, keywords in CATEGORY_KEYWORDS.items():
        if any(keyword in text_l for keyword in keywords):
            detected.append(category)

    if toxic_scores.get("threat", 0) >= 45 and "Direct Physical Threat" not in detected:
        detected.append("Direct Physical Threat")
    if (toxic_scores.get("insult", 0) >= 50 or toxic_scores.get("toxic", 0) >= 75) and "Severe Harassment" not in detected:
        detected.append("Severe Harassment")
    if toxic_scores.get("identity_hate", 0) >= 35 and "Identity Hate & Racism" not in detected:
        detected.append("Identity Hate & Racism")
    if toxic_scores.get("obscene", 0) >= 60 and "Obscenity & Vulgarity" not in detected:
        detected.append("Obscenity & Vulgarity")

    return detected or ["None (Benign)"]
