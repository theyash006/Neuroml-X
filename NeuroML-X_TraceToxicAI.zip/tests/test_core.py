"""
Comprehensive Test Suite for NEUROML-X TRACE TOXIC AI.
Verifies:
1. Safe benign text
2. Toxic text detection
3. Cyberbullying & threat detection
4. Empty and whitespace input handling
5. Very long input handling (truncation & resilience)
6. Nemotron service offline / failure fallback
7. Invalid API key graceful handling
8. ML heuristic fallback when deep learning models are offline
"""

import unittest
import sys
import os

# Add root directory to sys.path
root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

from utils.preprocessing import anonymize_text, normalize_text
from utils.risk_analysis import compute_combined_severity, get_risk_tier
from services.ml_service import (
    detect_toxicity_fallback,
    detect_emotion_fallback,
    detect_categories,
    TOXIC_LABELS
)
from services.nemotron_service import NemotronAgentService

class TestNeuroMLXCore(unittest.TestCase):

    def setUp(self):
        self.nemotron = NemotronAgentService(api_key="") # Unset key triggers safe local fallback

    def test_safe_benign_text(self):
        """Verify that positive, civil text receives low severity and SAFE classification."""
        text = "Hey! Great job on the presentation today, everyone really loved your ideas!"
        normalized = normalize_text(anonymize_text(text))
        tox_scores = detect_toxicity_fallback(normalized)
        top_emo, emo_conf, all_emo = detect_emotion_fallback(normalized)
        cats = detect_categories(normalized, tox_scores)
        agent_res = self.nemotron.analyze_single_message(normalized, tox_scores, top_emo, emo_conf, cats)
        severity = compute_combined_severity(tox_scores, all_emo, agent_res)
        tier = get_risk_tier(severity)

        self.assertEqual(agent_res["classification"], "SAFE")
        self.assertLess(severity, 30.0)
        self.assertIn(tier["code"], ["SAFE", "LOW"])

    def test_direct_toxic_text(self):
        """Verify that hostile insults trigger toxic classification and higher severity."""
        text = "You are so stupid and such an idiot, get lost."
        normalized = normalize_text(anonymize_text(text))
        tox_scores = detect_toxicity_fallback(normalized)
        top_emo, emo_conf, all_emo = detect_emotion_fallback(normalized)
        cats = detect_categories(normalized, tox_scores)
        agent_res = self.nemotron.analyze_single_message(normalized, tox_scores, top_emo, emo_conf, cats)
        severity = compute_combined_severity(tox_scores, all_emo, agent_res)

        self.assertIn(agent_res["classification"], ["TOXIC", "CYBERBULLYING", "SEVERE HARASSMENT"])
        self.assertGreaterEqual(severity, 40.0)

    def test_cyberbullying_and_threats(self):
        """Verify that explicit physical threats trigger critical risk and actionable safety advice."""
        text = "I know where you live, watch your back because I will kill you tonight 😡🔪"
        normalized = normalize_text(anonymize_text(text))
        tox_scores = detect_toxicity_fallback(normalized)
        top_emo, emo_conf, all_emo = detect_emotion_fallback(normalized)
        cats = detect_categories(normalized, tox_scores)
        agent_res = self.nemotron.analyze_single_message(normalized, tox_scores, top_emo, emo_conf, cats)
        severity = compute_combined_severity(tox_scores, all_emo, agent_res)
        tier = get_risk_tier(severity)

        self.assertEqual(agent_res["classification"], "SEVERE HARASSMENT")
        self.assertGreaterEqual(severity, 75.0)
        self.assertIn(tier["code"], ["HIGH", "CRITICAL"])
        self.assertIn("Direct Physical Threat", cats)

    def test_empty_and_whitespace_input(self):
        """Verify that empty, blank, or whitespace inputs do not crash and produce safe defaults."""
        for empty_val in ["", "   ", "\n\t  \n"]:
            normalized = normalize_text(anonymize_text(empty_val))
            tox_scores = detect_toxicity_fallback(normalized)
            top_emo, emo_conf, all_emo = detect_emotion_fallback(normalized)
            agent_res = self.nemotron.analyze_single_message(normalized, tox_scores, top_emo, emo_conf, ["None"])
            severity = compute_combined_severity(tox_scores, all_emo, agent_res)

            self.assertEqual(severity, 0.0)
            self.assertEqual(agent_res["classification"], "SAFE")

    def test_very_long_input(self):
        """Verify that long repetitive text (e.g. 10,000 chars) processes cleanly without error."""
        long_text = "This is a benign message that is repeated many times. " * 300
        anonymized = anonymize_text(long_text)
        normalized = normalize_text(anonymized)
        tox_scores = detect_toxicity_fallback(normalized)
        self.assertEqual(len(tox_scores), len(TOXIC_LABELS))

    def test_nemotron_service_fallback(self):
        """Verify that when no API key is provided, Nemotron service gracefully marks is_fallback=True."""
        offline_service = NemotronAgentService(api_key="")
        self.assertFalse(offline_service.is_available)
        res = offline_service.analyze_single_message(
            "test text", {"toxic": 10.0}, "neutral", 0.9, ["None"]
        )
        self.assertTrue(res["is_fallback"])
        self.assertIn("fallback", res["engine"].lower())

    def test_invalid_api_key_handling(self):
        """Verify that an invalid/dummy API key triggers fallback on network call rather than crashing."""
        dummy_service = NemotronAgentService(api_key="sk-invalid-test-key-12345", base_url="http://invalid.local/v1")
        # Attempting analysis with invalid endpoint will encounter network error and fallback
        res = dummy_service.analyze_single_message(
            "You loser", {"toxic": 85.0, "insult": 80.0}, "anger", 0.9, ["Severe Harassment"]
        )
        self.assertTrue(res["is_fallback"])
        self.assertIn("classification", res)

    def test_conversation_analyzer(self):
        """Verify that multi-turn conversation escalation is tracked correctly."""
        turns = [
            {"speaker": "UserA", "text": "Can you help me with homework?"},
            {"speaker": "UserB", "text": "Shut up you useless idiot."},
            {"speaker": "UserB", "text": "I will find you and beat you up."}
        ]
        turn_scores = [
            {"peak_toxicity": 5.0, "top_emotion": "neutral", "severity": 10.0},
            {"peak_toxicity": 65.0, "top_emotion": "anger", "severity": 68.0},
            {"peak_toxicity": 92.0, "top_emotion": "anger", "severity": 95.0}
        ]
        conv_res = self.nemotron.analyze_conversation(turns, turn_scores)
        self.assertTrue(conv_res["escalation_detected"])
        self.assertIn(conv_res["overall_classification"], ["CYBERBULLYING", "SEVERE HARASSMENT"])

if __name__ == "__main__":
    unittest.main()
