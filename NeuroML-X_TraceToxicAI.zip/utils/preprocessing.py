"""
Text Preprocessing and Sanitization Module for NEUROML-X TRACE TOXIC AI.
Preserves client-side PII privacy, maps emojis to semantic descriptors,
expands internet abbreviations, and collapses elongated characters.
"""

import re

SLANG_MAP = {
    "u": "you",
    "ur": "your",
    "r": "are",
    "brb": "be right back",
    "idk": "i do not know",
    "wtf": "what the fuck",
    "stfu": "shut the fuck up",
    "kys": "kill yourself",
    "gtfo": "get the fuck out",
    "lmao": "laughing my ass off",
    "rofl": "rolling on the floor laughing",
    "smh": "shaking my head",
    "tbh": "to be honest",
    "imo": "in my opinion",
    "bitch": "bitch",
    "loser": "loser",
    "noob": "beginner",
}

EMOJI_MAP = {
    "😡": " rage ",
    "🤬": " swearing rage ",
    "🔥": " aggressive intensity ",
    "👎": " severe dislike ",
    "😢": " sadness ",
    "😭": " crying distress ",
    "😂": " mocking laughter ",
    "💀": " death intimidation ",
    "🤡": " clown mocking ",
    "🤮": " disgust ",
    "🔪": " violence threat ",
    "👊": " physical attack ",
    "💔": " heartbreak ",
}

def anonymize_text(text: str) -> str:
    """
    Strips and redacts sensitive PII (Phone numbers, emails, links, @mentions).
    Ensures user privacy before content is analyzed.
    """
    if not text:
        return ""
    # Phone numbers (international, hyphenated, parenthesized, 10-digit)
    text = re.sub(
        r"(\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b",
        "[REDACTED PHONE]",
        text,
    )
    text = re.sub(r"\b\d{10}\b", "[REDACTED PHONE]", text)
    # Emails
    text = re.sub(r"[\w\.-]+@[\w\.-]+\.\w+", "[REDACTED EMAIL]", text)
    # URLs & Links
    text = re.sub(r"https?://\S+|www\.\S+", "[REDACTED URL]", text)
    # User handles
    text = re.sub(r"@[\w_]+", "[REDACTED USER]", text)
    return text

def normalize_text(text: str) -> str:
    """
    Replaces emojis with semantic labels, expands internet slang using regex boundaries,
    and collapses elongated characters (e.g. looooser -> looser).
    """
    if not text:
        return ""
    # Emojis to semantic meaning
    for emoji, meaning in EMOJI_MAP.items():
        text = text.replace(emoji, meaning)

    # Collapse elongated characters (3 or more identical characters -> 2)
    text = re.sub(r"(.)\1{2,}", r"\1\1", text)

    # Replace slang using regex word boundaries to preserve surrounding punctuation
    for slang, replacement in SLANG_MAP.items():
        pattern = r"\b" + re.escape(slang) + r"\b"
        text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)

    # Clean whitespace
    text = re.sub(r"\s+", " ", text).strip()
    return text
