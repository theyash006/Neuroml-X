"""
In-Memory PDF Incident Report Generator for NEUROML-X TRACE TOXIC AI.
Generates institutional, court/school-admissible digital safety incident summaries
combining Deep Learning scores with NVIDIA Nemotron agentic reasoning.
Zero Windows disk locks using BytesIO buffer.
"""

import io
from datetime import datetime
import numpy as np
import xml.sax.saxutils as saxutils
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
from typing import Dict, Any, List

def generate_pdf_report(
    raw_text: str,
    anonymized_text: str,
    toxicity_scores: Dict[str, float],
    top_emotion: str,
    emotion_confidence: float,
    all_emotions: Dict[str, float],
    categories: List[str],
    severity: float,
    nemotron_reasoning: Dict[str, Any],
    ml_engine_name: str,
) -> bytes:
    """Compiles clean, multi-section ReportLab PDF in memory and returns bytes."""
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        leftMargin=40,
        rightMargin=40,
        topMargin=40,
        bottomMargin=40,
    )

    styles = getSampleStyleSheet()
    story = []

    # Document Header
    title_style = ParagraphStyle(
        "DocTitle",
        parent=styles["Heading1"],
        fontSize=20,
        textColor=colors.HexColor("#0f172a"),
        spaceAfter=4,
    )
    subtitle_style = ParagraphStyle(
        "DocSub",
        parent=styles["Normal"],
        fontSize=9.5,
        textColor=colors.HexColor("#64748b"),
        spaceAfter=12,
    )

    story.append(Paragraph("🛡️ NEUROML-X : TRACE TOXIC AI", title_style))
    story.append(Paragraph("DIGITAL SAFETY & HARASSMENT INCIDENT REPORT", ParagraphStyle("SubH", parent=title_style, fontSize=13, textColor=colors.HexColor("#2563eb"))))

    now_str = datetime.now().strftime("%B %d, %Y at %I:%M:%S %p")
    doc_id = f"NMX-{datetime.now().strftime('%Y%m%d')}-{np.random.randint(1000, 9999)}"
    nemotron_engine = nemotron_reasoning.get("engine", "NVIDIA Nemotron via Nebius Token Factory")
    story.append(Paragraph(f"Reference ID: <b>{doc_id}</b> | Timestamp: {now_str}<br/>ML Engine: <b>{ml_engine_name}</b> | Agent: <b>{nemotron_engine}</b>", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor("#2563eb"), spaceAfter=14))

    # Risk Callout Block
    risk_title = (
        "CRITICAL RISK (Tier 5)" if severity >= 81
        else ("HIGH RISK (Tier 4)" if severity >= 61
        else ("MODERATE RISK (Tier 3)" if severity >= 41
        else ("LOW RISK (Tier 2)" if severity >= 21 else "SAFE (Tier 1)")))
    )
    risk_color = (
        colors.HexColor("#ef4444") if severity >= 81
        else (colors.HexColor("#f97316") if severity >= 61
        else (colors.HexColor("#f59e0b") if severity >= 41
        else (colors.HexColor("#38bdf8") if severity >= 21 else colors.HexColor("#10b981"))))
    )

    risk_data = [
        [
            Paragraph(f"<b>CLASSIFICATION:</b> {nemotron_reasoning.get('classification', 'SAFE')}", ParagraphStyle("RiskT", parent=styles["Normal"], textColor=colors.white, fontName="Helvetica-Bold", fontSize=11)),
            Paragraph(f"<b>SEVERITY INDEX:</b> {severity:.1f}/100 ({risk_title})", ParagraphStyle("RiskS", parent=styles["Normal"], textColor=colors.white, fontName="Helvetica-Bold", fontSize=11, alignment=2))
        ]
    ]
    t_risk = Table(risk_data, colWidths=[260, 260])
    t_risk.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), risk_color),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("LEFTPADDING", (0, 0), (-1, -1), 12),
        ("RIGHTPADDING", (0, 0), (-1, -1), 12),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    story.append(t_risk)
    story.append(Spacer(1, 14))

    # Section 1: Sanitized Content
    h2_style = ParagraphStyle("H2", parent=styles["Heading2"], fontSize=12, textColor=colors.HexColor("#1e293b"), spaceAfter=6)
    story.append(Paragraph("1. Evaluated Content (PII-Sanitized)", h2_style))
    safe_text = saxutils.escape(anonymized_text).replace("\n", "<br/>")
    text_table = Table([[Paragraph(f"<i>\"{safe_text}\"</i>", styles["Normal"])]], colWidths=[520])
    text_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f8fafc")),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
        ("PADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(text_table)
    story.append(Spacer(1, 12))

    # Section 2: NVIDIA Nemotron Contextual Reasoning
    story.append(Paragraph("2. NVIDIA Nemotron Agentic Reasoning", h2_style))
    signals_bullet = "<br/>".join([f"• {s}" for s in nemotron_reasoning.get("detected_signals", [])])
    agent_summary = (
        f"<b>Context & Intent:</b> {nemotron_reasoning.get('context_intent', 'N/A')}<br/>"
        f"<b>Detected Signals:</b><br/>{signals_bullet}<br/>"
        f"<b>Explainability:</b> {nemotron_reasoning.get('explanation', 'N/A')}"
    )
    agent_table = Table([[Paragraph(agent_summary, styles["Normal"])]], colWidths=[520])
    agent_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f0fdf4")),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#86efac")),
        ("PADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(agent_table)
    story.append(Spacer(1, 12))

    # Section 3: Machine Learning Quantitative Scores
    story.append(Paragraph("3. Deep Learning Feature Distribution", h2_style))
    tox_rows = [["Dimension", "Model Probability", "Risk Tier"]]
    for k, v in toxicity_scores.items():
        tier = "Critical (>70%)" if v >= 70 else ("Moderate (40-69%)" if v >= 40 else "Safe (<40%)")
        tox_rows.append([k.replace("_", " ").title(), f"{v:.2f}%", tier])

    t_tox = Table(tox_rows, colWidths=[200, 160, 160])
    t_tox.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1e293b")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e2e8f0")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f8fafc")]),
        ("PADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(t_tox)
    story.append(Spacer(1, 12))

    # Section 4: Recommended Interventions
    story.append(Paragraph("4. Recommended Protective Action & Response", h2_style))
    rec_content = (
        f"<b>Recommended Safety Measure:</b> {nemotron_reasoning.get('recommended_action', 'None')}<br/><br/>"
        f"<b>De-escalating / Protective Response Option:</b><br/>"
        f"<i>\"{nemotron_reasoning.get('safe_victim_response', '')}\"</i>"
    )
    rec_table = Table([[Paragraph(rec_content, styles["Normal"])]], colWidths=[520])
    rec_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#eff6ff")),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#bfdbfe")),
        ("PADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(rec_table)

    story.append(Spacer(1, 16))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#cbd5e1"), spaceAfter=6))
    story.append(Paragraph(
        "<i>Disclaimer: NEUROML-X TRACE TOXIC AI is an automated screening and early-warning aid. "
        "It does not provide psychiatric diagnoses or legal determinations. Consult official legal authorities for critical interventions.</i>",
        ParagraphStyle("Foot", parent=styles["Normal"], fontSize=7.5, textColor=colors.HexColor("#94a3b8"))
    ))

    doc.build(story)
    pdf_bytes = buffer.getvalue()
    buffer.close()
    return pdf_bytes
