"""
Risk Analysis and Toxicity Severity Computation for NEUROML-X.
Combines:
- ML sequence classification probabilities (toxic, threat, insult, etc.)
- Emotional intensity modulation (anger, disgust)
- Agentic contextual signals from NVIDIA Nemotron
- Repetition / harassment indicators
Produces unified 0-100 severity scores calibrated across 5 risk tiers.
"""

from typing import Dict, Any, List

def compute_combined_severity(
    toxic_scores: Dict[str, float],
    all_emotions: Dict[str, float],
    nemotron_reasoning: Dict[str, Any]
) -> float:
    """
    Computes unified severity score (0 - 100) combining first-pass ML
    probabilities with NVIDIA Nemotron agentic reasoning.
    """
    if not toxic_scores:
        return 0.0

    toxic = toxic_scores.get("toxic", 0.0) / 100.0
    severe_toxic = toxic_scores.get("severe_toxic", 0.0) / 100.0
    threat = toxic_scores.get("threat", 0.0) / 100.0
    insult = toxic_scores.get("insult", 0.0) / 100.0
    obscene = toxic_scores.get("obscene", 0.0) / 100.0
    identity_hate = toxic_scores.get("identity_hate", 0.0) / 100.0

    # Base ML weighted score
    ml_base = (
        0.25 * toxic
        + 0.20 * severe_toxic
        + 0.25 * threat
        + 0.15 * insult
        + 0.05 * obscene
        + 0.10 * identity_hate
    )

    # Emotion amplification factor (elevated anger or disgust modulates severity)
    anger = all_emotions.get("anger", 0.0) / 100.0
    disgust = all_emotions.get("disgust", 0.0) / 100.0
    emotion_modulator = 1.0 + 0.15 * max(anger, disgust)

    ml_severity = ml_base * 100.0 * emotion_modulator

    # Nemotron contextual modifier
    nemotron_cls = nemotron_reasoning.get("classification", "SAFE")
    tier_boost = {
        "SAFE": 0.0,
        "POSSIBLY TOXIC": 5.0,
        "TOXIC": 12.0,
        "CYBERBULLYING": 20.0,
        "SEVERE HARASSMENT": 30.0
    }.get(nemotron_cls, 0.0)

    # Blend ML severity (75%) + Nemotron contextual calibration (25%)
    combined = (0.75 * ml_severity) + (0.25 * (ml_severity + tier_boost))

    # Explicit physical threat cap: if threat >= 70%, ensure score is in Critical tier
    if threat >= 0.70:
        combined = max(combined, 82.0)
    elif nemotron_cls == "SEVERE HARASSMENT":
        combined = max(combined, 81.0)
    elif nemotron_cls == "SAFE" and ml_severity < 20.0:
        combined = min(combined, 18.0)

    return round(float(min(100.0, max(0.0, combined))), 2)

def get_risk_tier(severity: float) -> Dict[str, str]:
    """
    Categorizes severity into standardized risk tiers with styling attributes:
    0–20: Safe
    21–40: Low Risk
    41–60: Moderate Risk
    61–80: High Risk
    81–100: Critical Risk
    """
    if severity >= 81.0:
        return {
            "tier": "Critical Risk",
            "code": "CRITICAL",
            "color": "#ef4444",
            "badge_class": "alert-critical",
            "recommendation": "Imminent threat or extreme harassment. Preserve evidence, block immediately, and alert authorities."
        }
    elif severity >= 61.0:
        return {
            "tier": "High Risk",
            "code": "HIGH",
            "color": "#f97316",
            "badge_class": "alert-high",
            "recommendation": "Severe cyberbullying or targeted aggression. Document incidents, disengage, and consult support."
        }
    elif severity >= 41.0:
        return {
            "tier": "Moderate Risk",
            "code": "MODERATE",
            "color": "#f59e0b",
            "badge_class": "alert-medium",
            "recommendation": "Hostile or toxic content detected. Set boundaries and monitor for repetition."
        }
    elif severity >= 21.0:
        return {
            "tier": "Low Risk",
            "code": "LOW",
            "color": "#38bdf8",
            "badge_class": "alert-low",
            "recommendation": "Mild negativity or ambiguous tone. Standard digital caution advised."
        }
    else:
        return {
            "tier": "Safe",
            "code": "SAFE",
            "color": "#10b981",
            "badge_class": "alert-safe",
            "recommendation": "Content appears civil, constructive, and free of harmful intent."
        }

RISK_DISCLAIMER = (
    "AI-Assisted Assessment Notice: The severity score and classification are automated estimates "
    "produced by Machine Learning and NVIDIA Nemotron. They are not psychological diagnoses or legal determinations."
)
