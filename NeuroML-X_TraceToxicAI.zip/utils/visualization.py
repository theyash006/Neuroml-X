"""
Visualization Helpers using Plotly for NEUROML-X TRACE TOXIC AI.
Provides hackathon-grade charts styled for dark cyber aesthetic:
- Toxicity breakdown bar charts
- Emotion polar radar charts
- Conversation turn-by-turn toxicity progression timelines
- Aggregate session risk distribution charts
"""

import plotly.graph_objects as go
import plotly.express as px
from typing import Dict, List, Any

def create_toxicity_bar_chart(toxic_scores: Dict[str, float]) -> go.Figure:
    """Generates vertical bar chart for 6 toxicity dimensions with color-coded risk tiers."""
    labels = [k.replace("_", " ").title() for k in toxic_scores.keys()]
    values = list(toxic_scores.values())

    bar_colors = []
    for val in values:
        if val >= 70:
            bar_colors.append("#ef4444")
        elif val >= 40:
            bar_colors.append("#f59e0b")
        else:
            bar_colors.append("#10b981")

    fig = go.Figure(
        data=[
            go.Bar(
                x=labels,
                y=values,
                text=[f"{v:.1f}%" for v in values],
                textposition="auto",
                marker=dict(
                    color=bar_colors,
                    line=dict(color="rgba(255,255,255,0.2)", width=1),
                ),
                hovertemplate="<b>%{x}</b>: %{y:.2f}%<extra></extra>",
            )
        ]
    )

    fig.update_layout(
        height=320,
        margin=dict(l=20, r=20, t=20, b=20),
        xaxis=dict(tickangle=-25, showgrid=False),
        yaxis=dict(range=[0, 100], showgrid=True, gridcolor="rgba(255,255,255,0.06)"),
        plot_bgcolor="rgba(0,0,0,0)",
        paper_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#e2e8f0", size=12),
    )
    return fig

def create_emotion_radar_chart(all_emotions: Dict[str, float]) -> go.Figure:
    """Generates closed radar plot for 7 emotional intensity dimensions."""
    emo_keys = [k.title() for k in all_emotions.keys()]
    emo_vals = list(all_emotions.values())
    emo_keys_loop = emo_keys + [emo_keys[0]]
    emo_vals_loop = emo_vals + [emo_vals[0]]

    fig = go.Figure(
        data=[
            go.Scatterpolar(
                r=emo_vals_loop,
                theta=emo_keys_loop,
                fill="toself",
                fillcolor="rgba(56, 189, 248, 0.25)",
                line=dict(color="#38bdf8", width=2),
                hovertemplate="<b>%{theta}</b>: %{r:.1f}%<extra></extra>",
            )
        ]
    )
    fig.update_layout(
        height=320,
        margin=dict(l=30, r=30, t=20, b=20),
        polar=dict(
            radialaxis=dict(visible=True, range=[0, 100], showticklabels=False, linecolor="rgba(255,255,255,0.1)"),
            angularaxis=dict(linecolor="rgba(255,255,255,0.2)", gridcolor="rgba(255,255,255,0.08)"),
            bgcolor="rgba(0,0,0,0)",
        ),
        paper_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#e2e8f0", size=11),
    )
    return fig

def create_conversation_timeline_chart(
    turns: List[Dict[str, str]],
    turn_scores: List[Dict[str, Any]]
) -> go.Figure:
    """Renders line chart showing toxicity evolution across multi-turn dialogue."""
    turn_labels = [f"Turn {i+1} ({t.get('speaker', 'User')})" for i, t in enumerate(turns)]
    tox_values = [s.get("peak_toxicity", 0.0) for s in turn_scores]
    severity_values = [s.get("severity", 0.0) for s in turn_scores]

    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=turn_labels,
            y=tox_values,
            mode="lines+markers",
            name="Peak Toxicity",
            line=dict(color="#ef4444", width=3),
            marker=dict(size=9, color="#ef4444")
        )
    )
    fig.add_trace(
        go.Scatter(
            x=turn_labels,
            y=severity_values,
            mode="lines+markers",
            name="Severity Index",
            line=dict(color="#f59e0b", width=2, dash="dot"),
            marker=dict(size=7, color="#f59e0b")
        )
    )

    fig.update_layout(
        title="Conversation Escalation & Toxicity Progression",
        height=340,
        margin=dict(l=20, r=20, t=40, b=20),
        yaxis=dict(range=[0, 105], title="Score (0-100)", gridcolor="rgba(255,255,255,0.06)"),
        xaxis=dict(showgrid=False),
        plot_bgcolor="rgba(0,0,0,0)",
        paper_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#e2e8f0", size=12),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    return fig

def create_risk_distribution_chart(history: List[Dict[str, Any]]) -> go.Figure:
    """Visualizes distribution of risk tiers across current session."""
    if not history:
        fig = go.Figure()
        fig.update_layout(
            annotations=[dict(text="No scans recorded in this session yet.", showarrow=False, font=dict(color="#94a3b8", size=14))],
            plot_bgcolor="rgba(0,0,0,0)",
            paper_bgcolor="rgba(0,0,0,0)",
            height=260
        )
        return fig

    tiers = {"Safe": 0, "Low Risk": 0, "Moderate Risk": 0, "High Risk": 0, "Critical Risk": 0}
    for item in history:
        sev = item.get("severity", 0.0)
        if sev >= 81:
            tiers["Critical Risk"] += 1
        elif sev >= 61:
            tiers["High Risk"] += 1
        elif sev >= 41:
            tiers["Moderate Risk"] += 1
        elif sev >= 21:
            tiers["Low Risk"] += 1
        else:
            tiers["Safe"] += 1

    fig = go.Figure(
        data=[
            go.Bar(
                x=list(tiers.keys()),
                y=list(tiers.values()),
                marker=dict(
                    color=["#10b981", "#38bdf8", "#f59e0b", "#f97316", "#ef4444"]
                ),
                text=list(tiers.values()),
                textposition="auto"
            )
        ]
    )
    fig.update_layout(
        title="Session Scan Risk Distribution",
        height=280,
        margin=dict(l=20, r=20, t=40, b=20),
        yaxis=dict(title="Count", gridcolor="rgba(255,255,255,0.06)"),
        xaxis=dict(showgrid=False),
        plot_bgcolor="rgba(0,0,0,0)",
        paper_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#e2e8f0", size=11)
    )
    return fig
