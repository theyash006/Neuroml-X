"""
Risk and Pattern Engine for TraceToxicAI.
Calculates multidimensional risk scores (0-100) from AI signals, message severity,
repetition, coordinated multi-sender activity, and escalation trends.
Includes incident deduplication.
"""

from dataclasses import dataclass
from typing import List, Dict, Optional, Tuple
from enum import Enum
import time

class RiskLevel(str, Enum):
    LOW = "LOW"
    MODERATE = "MODERATE"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"

@dataclass
class IncidentRecord:
    incident_id: str
    timestamp: float
    app_source: str
    sender_id: str
    message_text: str
    category: str
    toxicity_score: float
    threat_score: float
    ai_confidence: float
    risk_score: int
    risk_level: RiskLevel
    detected_patterns: List[str]
    explanations: List[str]
    status: str = "PENDING_REVIEW" # PENDING_REVIEW, SAVED_VAULT, DISMISSED

class IncidentDeduplicator:
    """
    Prevents the same notification from being counted multiple times.
    Deduplication window: e.g. within 60 seconds of identical text, sender, and app.
    """
    def __init__(self, window_seconds: float = 60.0):
        self.window_seconds = window_seconds
        self.recent_events: List[Tuple[str, str, str, float]] = [] # (text, sender, app, timestamp)

    def is_duplicate(self, text: str, sender: str, app: str, timestamp: float) -> bool:
        # Prune older than window
        self.recent_events = [e for e in self.recent_events if timestamp - e[3] <= self.window_seconds]
        
        normalized_text = text.strip().lower()
        for past_text, past_sender, past_app, past_time in self.recent_events:
            if (past_text == normalized_text and 
                past_sender == sender and 
                past_app == app and 
                abs(timestamp - past_time) <= self.window_seconds):
                return True
                
        self.recent_events.append((normalized_text, sender, app, timestamp))
        return False

class RepetitionDetector:
    """
    Detects repeated harmful messages originating from the same sender.
    """
    def evaluate(self, sender: str, history: List[IncidentRecord]) -> Tuple[int, Optional[str]]:
        # Count harmful messages from this sender in history
        harmful_from_sender = [
            inc for inc in history 
            if inc.sender_id == sender and inc.category != "NORMAL" and inc.toxicity_score >= 0.50
        ]
        count = len(harmful_from_sender)
        
        if count >= 3:
            return 25, f"Potential repeated harassment pattern detected ({count + 1} incidents from sender '{sender}')"
        elif count >= 1:
            return 12, f"Repeated negative interaction detected ({count + 1} incidents from '{sender}')"
        
        return 0, None

class MultiSenderDetector:
    """
    Detects coordinated or group harassment where multiple senders target the user.
    """
    def evaluate(self, current_sender: str, history: List[IncidentRecord], window_hours: float = 24.0) -> Tuple[int, Optional[str]]:
        now = time.time()
        # Find unique senders with harmful messages in the recent window
        recent_senders = set(
            inc.sender_id for inc in history
            if (now - inc.timestamp <= window_hours * 3600) and 
               inc.sender_id != current_sender and 
               inc.category != "NORMAL" and 
               inc.toxicity_score >= 0.50
        )
        
        if len(recent_senders) >= 2:
            return 20, f"Potential multi-sender harassment pattern detected ({len(recent_senders) + 1} distinct sources)"
        elif len(recent_senders) == 1:
            return 8, "Multiple unique individuals have sent harmful messages recently"
            
        return 0, None

class TrendAnalyzer:
    """
    Analyzes historical progression to detect escalation trends.
    """
    def evaluate(self, current_toxicity: float, history: List[IncidentRecord]) -> Tuple[int, Optional[str]]:
        if len(history) < 2:
            return 0, None
            
        recent_toxicity_scores = [inc.toxicity_score for inc in history[-3:] if inc.category != "NORMAL"]
        if len(recent_toxicity_scores) >= 2:
            avg_past = sum(recent_toxicity_scores) / len(recent_toxicity_scores)
            if current_toxicity > avg_past + 0.20:
                return 15, "The system estimates an increasing risk pattern compared to previous communications"
                
        return 0, None

class RiskCalculator:
    """
    Combines AI classification with historical context to determine objective risk.
    Scoring weights:
    - Base Toxicity: 35%
    - Threat Score: 35%
    - Repetition penalty: up to 25%
    - Multi-sender penalty: up to 20%
    - Escalation trend penalty: up to 15%
    Total normalized to 0-100.
    """
    def __init__(self):
        self.repetition_detector = RepetitionDetector()
        self.multi_sender_detector = MultiSenderDetector()
        self.trend_analyzer = TrendAnalyzer()
        self.deduplicator = IncidentDeduplicator()

    def calculate_risk(
        self,
        toxicity_score: float,
        threat_score: float,
        category: str,
        sender_id: str,
        history: List[IncidentRecord]
    ) -> Tuple[int, RiskLevel, List[str]]:
        if category == "NORMAL":
            return int(toxicity_score * 15), RiskLevel.LOW, []

        patterns = []
        
        # Base severity: Threat has very heavy weighting
        base_score = (toxicity_score * 35.0) + (threat_score * 45.0)
        
        # Check repetition
        rep_penalty, rep_msg = self.repetition_detector.evaluate(sender_id, history)
        if rep_msg:
            patterns.append(rep_msg)
            
        # Check multi-sender
        multi_penalty, multi_msg = self.multi_sender_detector.evaluate(sender_id, history)
        if multi_msg:
            patterns.append(multi_msg)
            
        # Check escalation
        trend_penalty, trend_msg = self.trend_analyzer.evaluate(toxicity_score, history)
        if trend_msg:
            patterns.append(trend_msg)
            
        # Compute combined score capped at 100
        total_risk = int(min(100.0, max(0.0, base_score + rep_penalty + multi_penalty + trend_penalty)))
        
        # Risk level categorization
        if total_risk <= 25:
            level = RiskLevel.LOW
        elif total_risk <= 50:
            level = RiskLevel.MODERATE
        elif total_risk <= 75:
            level = RiskLevel.HIGH
        else:
            level = RiskLevel.CRITICAL

        return total_risk, level, patterns
