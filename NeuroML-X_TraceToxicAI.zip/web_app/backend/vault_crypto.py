"""
Encrypted Evidence Vault for TraceToxicAI.
Implements AES-GCM-256 authenticated encryption with PBKDF2 key derivation from user PIN.
Handles incident persistence, decryption, and data retention cleanup policies.
"""

import os
import json
import base64
import time
from typing import List, Optional, Dict, Any
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

class EvidenceVault:
    def __init__(self, storage_dir: str = "vault_data"):
        self.storage_dir = storage_dir
        os.makedirs(self.storage_dir, exist_ok=True)
        self.salt_file = os.path.join(self.storage_dir, "vault.salt")
        self.data_file = os.path.join(self.storage_dir, "vault_encrypted.bin")
        self.retention_days = 30 # Default 30 days
        self._ensure_salt()

    def _ensure_salt(self):
        if not os.path.exists(self.salt_file):
            salt = os.urandom(16)
            with open(self.salt_file, "wb") as f:
                f.write(salt)

    def _get_salt(self) -> bytes:
        with open(self.salt_file, "rb") as f:
            return f.read()

    def _derive_key(self, pin: str) -> bytes:
        salt = self._get_salt()
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        return kdf.derive(pin.encode('utf-8'))

    def save_incidents(self, incidents: List[Dict[str, Any]], pin: str) -> bool:
        """
        Encrypts incidents list with AES-GCM-256 using key derived from user PIN.
        """
        try:
            key = self._derive_key(pin)
            aesgcm = AESGCM(key)
            nonce = os.urandom(12)
            
            plaintext = json.dumps(incidents).encode('utf-8')
            ciphertext = aesgcm.encrypt(nonce, plaintext, None)
            
            payload = {
                "nonce": base64.b64encode(nonce).decode('utf-8'),
                "ciphertext": base64.b64encode(ciphertext).decode('utf-8'),
                "last_updated": time.time()
            }
            
            with open(self.data_file, "w") as f:
                json.dump(payload, f)
            return True
        except Exception as e:
            print(f"Error saving to vault: {e}")
            return False

    def load_incidents(self, pin: str) -> Optional[List[Dict[str, Any]]]:
        """
        Decrypts vault incidents using user PIN.
        Returns None if PIN is invalid or file corrupted.
        """
        if not os.path.exists(self.data_file):
            return []

        try:
            with open(self.data_file, "r") as f:
                payload = json.load(f)
                
            nonce = base64.b64decode(payload["nonce"])
            ciphertext = base64.b64decode(payload["ciphertext"])
            
            key = self._derive_key(pin)
            aesgcm = AESGCM(key)
            plaintext = aesgcm.decrypt(nonce, ciphertext, None)
            
            incidents = json.loads(plaintext.decode('utf-8'))
            return incidents
        except Exception:
            # Authentication tag mismatch (wrong PIN) or corrupted ciphertext
            return None

    def enforce_retention(self, incidents: List[Dict[str, Any]], retention_policy: str) -> List[Dict[str, Any]]:
        """
        Cleans up incidents older than specified retention policy:
        '7_days', '30_days', 'never'
        """
        if retention_policy == "never":
            return incidents
            
        days = 7 if retention_policy == "7_days" else 30
        cutoff = time.time() - (days * 86400)
        
        filtered = [inc for inc in incidents if inc.get("timestamp", 0) >= cutoff]
        return filtered
