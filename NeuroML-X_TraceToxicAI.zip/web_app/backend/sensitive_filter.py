"""
Sensitive Data Filter for TraceToxicAI.
Detects and drops sensitive non-message notifications (OTPs, banking alerts,
payment confirmations, 2FA tokens) BEFORE sending text to any AI model.
"""

import re
from typing import Tuple, Optional

class SensitiveDataFilter:
    def __init__(self):
        # Regular expressions for OTP, banking, 2FA, credit cards, transaction alerts
        self.otp_patterns = [
            re.compile(r'\b(?:otp|one[- ]time[- ]password|verification code|security code)\b', re.IGNORECASE),
            re.compile(r'\b(?:code|pin)\s*(?:is|:)?\s*\d{4,8}\b', re.IGNORECASE),
            re.compile(r'\b\d{4,8}\s*(?:is your (?:otp|verification code|secret pin))\b', re.IGNORECASE),
            re.compile(r'\bdo not share this (?:code|otp|pin) with anyone\b', re.IGNORECASE),
        ]
        
        self.banking_patterns = [
            re.compile(r'\b(?:debited|credited|transferred|withdrawn|refunded)\b', re.IGNORECASE),
            re.compile(r'\b(?:inr|rs\.?|usd|\$|eur|₹)\s*[\d,]+(?:\.\d{2})?\b', re.IGNORECASE),
            re.compile(r'\b(?:a/c|account)\s*(?:no\.?|ending)?\s*(?:x+|\*+)?\d{3,4}\b', re.IGNORECASE),
            re.compile(r'\b(?:upi|neft|rtgs|imps|atm|pos txn)\b', re.IGNORECASE),
            re.compile(r'\b(?:available balance|bal is|current bal)\b', re.IGNORECASE),
            re.compile(r'\b(?:netbanking|credit card statement|bill due)\b', re.IGNORECASE)
        ]
        
        self.auth_alert_patterns = [
            re.compile(r'\b(?:login alert|new sign-in|suspicious login|reset your password|two-factor authentication)\b', re.IGNORECASE),
            re.compile(r'\b(?:click here to reset your password)\b', re.IGNORECASE),
        ]

    def is_sensitive(self, text: str) -> Tuple[bool, Optional[str]]:
        """
        Evaluates whether the notification text contains sensitive data.
        Returns:
            (True, reason) if sensitive and must be skipped.
            (False, None) if clean for NLP processing.
        """
        if not text or not text.strip():
            return False, None

        # Check OTP
        for pattern in self.otp_patterns:
            if pattern.search(text):
                return True, "One-Time Password (OTP) or Verification Code detected"

        # Check Banking / Financial
        for pattern in self.banking_patterns:
            if pattern.search(text):
                return True, "Financial transaction or banking alert detected"

        # Check Auth / Password alert
        for pattern in self.auth_alert_patterns:
            if pattern.search(text):
                return True, "Security alert or password reset communication detected"

        return False, None
