"""
Multilingual NLP Detection Engine for TraceToxicAI.
Supports English, Hindi (Devanagari + Hinglish), and Punjabi (Gurmukhi + Romanized).
Provides OnDevice, Cloud, and Hybrid fallback architectures.
Adheres strictly to cautious, non-accusatory language.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from enum import Enum
import re
import unicodedata

class BullyingCategory(str, Enum):
    NORMAL = "NORMAL"
    VERBAL_BULLYING = "VERBAL_BULLYING"
    CYBERBULLYING = "CYBERBULLYING"
    THREAT = "THREAT"
    GROUP_HARASSMENT = "GROUP_HARASSMENT"
    BLACKMAIL = "BLACKMAIL"
    SOCIAL_EXCLUSION = "SOCIAL_EXCLUSION"
    SEXUAL_HARASSMENT = "SEXUAL_HARASSMENT"
    TOXIC_LANGUAGE = "TOXIC_LANGUAGE"

@dataclass
class DetectionInput:
    message_text: str
    sender_id: str
    app_source: str
    timestamp: float
    language: Optional[str] = None
    conversation_context: Optional[List[str]] = None

@dataclass
class DetectionResult:
    toxicity_score: float  # 0.0 - 1.0
    threat_score: float    # 0.0 - 1.0
    category: BullyingCategory
    confidence: float      # 0.0 - 1.0
    explanations: List[str]
    model_version: str
    detected_language: str
    engine_used: str

class LanguageDetector:
    @staticmethod
    def detect(text: str) -> str:
        # Check Gurmukhi script (Punjabi)
        if re.search(r'[\u0A00-\u0A7F]', text):
            return "Punjabi (Gurmukhi)"
        # Check Devanagari script (Hindi)
        if re.search(r'[\u0900-\u097F]', text):
            return "Hindi (Devanagari)"
        
        # Romanized keywords for Hindi / Hinglish
        hinglish_markers = ['tere', 'meri', 'tujhe', 'kameene', 'kutta', 'marunga', 'dekh', 'saale', 'bhai', 'sabko', 'chodenge']
        lower_words = text.lower().split()
        if any(w in hinglish_markers for w in lower_words):
            return "Hindi (Hinglish)"
            
        # Romanized keywords for Punjabi
        punjabi_markers = ['tainu', 'maran', 'chadna', 'saaleya', 'vekh', 'chup', 'karange', 'sare']
        if any(w in punjabi_markers for w in lower_words):
            return "Punjabi (Romanized)"
            
        return "English"

class TextNormalizer:
    @staticmethod
    def normalize(text: str) -> str:
        # Unicode normalization (NFKD)
        text = unicodedata.normalize('NFKD', text)
        # Collapse elongated characters (e.g. "looooser" -> "looser")
        text = re.sub(r'(.)\1{2,}', r'\1\1', text)
        # Collapse excessive whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        return text

class OnDeviceDetectionEngine:
    """
    On-device lightweight NLP classifier.
    Simulates on-device TFLite/ONNX distilled multilingual model with pattern rules.
    """
    def __init__(self):
        self.model_version = "TraceToxic-DistilMulti-v1.4-OnDevice"
        self._init_lexicons()

    def _init_lexicons(self):
        # Threat keywords
        self.threat_keywords = [
            # English
            "kill you", "beat you", "break your neck", "end your life", "you're dead",
            "watch your back", "find where you live", "hunt you down", "gonna hurt you",
            # Hindi (Devanagari)
            "जान से मार दूंगा", "तुझे खत्म कर दूंगा", "तेरे टुकड़े करूंगा", "घर आके मारूंगा", "बच के रहना",
            # Hinglish
            "jaan se maar doonga", "marunga tujhe", "khatam kar dunga", "bach ke rehna", "ghar aake marunga",
            # Punjabi (Gurmukhi)
            "ਤੈਨੂੰ ਜਾਨੋਂ ਮਾਰ ਦਿਆਂਗਾ", "ਤੇਰਾ ਕਤਲ ਕਰਾਂਗਾ", "ਘਰ ਆ ਕੇ ਕੁੱਟਾਂਗਾ",
            # Punjabi (Romanized)
            "tainu maar deyange", "kutteya maar dunga", "bach ke reh"
        ]

        # Blackmail / Coercion
        self.blackmail_keywords = [
            "leak your photos", "expose you", "send your pictures", "ruin your life",
            "pay me or else", "tell everyone your secret", "post your private chat",
            "सबको तेरी तस्वीरें भेज दूंगा", "तेरी फोटो वायरल कर दूंगा", "पैसे दे नहीं तो",
            "sabko photos bhej dunga", "viral kar dunga", "expose kar dunga",
            "ਤੇਰੀਆਂ ਫੋਟੋਆਂ ਵਾਇਰਲ ਕਰ ਦਿਆਂਗਾ"
        ]

        # Sexual harassment
        self.sexual_harassment_keywords = [
            "send nudes", "show your body", "strip for me", "sexy baby", "wanna touch you",
            "कपड़े उतार", "न्यूड्स भेज", "शरीर दिखा", "nudes bhej", "apne nudes bhej"
        ]

        # Social exclusion / Group harassment
        self.social_exclusion_keywords = [
            "nobody likes you", "get out of this group", "don't invite him", "loser don't talk to us",
            "everyone hates you", "leave our group", "कोई तुझसे बात नहीं करना चाहता",
            "ग्रुप से निकालो इसको", "sab tujhse nafrat karte hain", "group se bahar nikal",
            "ਸਾਰੇ ਤੈਨੂੰ ਨਫ਼ਰਤ ਕਰਦੇ ਹਨ", "ਕੋਈ ਤੇਰੇ ਨਾਲ ਗੱਲ ਨਹੀਂ ਕਰਦਾ"
        ]

        # Verbal bullying / Toxic language
        self.insult_keywords = [
            "loser", "idiot", "moron", "ugly", "worthless", "disgusting", "pathetic",
            "freak", "stupid", "dumbass", "creep", "kill yourself",
            "गधा", "कमीने", "बकवास", "बेवकूफ", "घटिया", "मनहूस",
            "kutta", "kameena", "ghatiya", "bewakoof", "chup kar kutte",
            "ਬੇਵਕੂਫ਼", "ਘਟੀਆ", "ਕੁੱਤਾ"
        ]

    def analyze(self, input_data: DetectionInput) -> DetectionResult:
        raw_text = input_data.message_text
        norm_text = TextNormalizer.normalize(raw_text).lower()
        lang = LanguageDetector.detect(raw_text)

        toxicity = 0.05
        threat = 0.02
        confidence = 0.60
        explanations = []
        category = BullyingCategory.NORMAL

        # Check Threats
        threat_matches = [kw for kw in self.threat_keywords if kw in norm_text]
        if threat_matches:
            category = BullyingCategory.THREAT
            threat = max(0.75, min(0.98, 0.70 + 0.10 * len(threat_matches)))
            toxicity = max(0.80, threat - 0.05)
            confidence = 0.94
            explanations.append("Explicit physical or bodily harm threats identified")
            explanations.append(f"Contains warning pattern: '{threat_matches[0]}'")

        # Check Blackmail
        elif any(kw in norm_text for kw in self.blackmail_keywords):
            category = BullyingCategory.BLACKMAIL
            threat = 0.65
            toxicity = 0.85
            confidence = 0.91
            explanations.append("Coercion or blackmail language detected")
            explanations.append("Potential extortion / unauthorized image leak threat pattern")

        # Check Sexual Harassment
        elif any(kw in norm_text for kw in self.sexual_harassment_keywords):
            category = BullyingCategory.SEXUAL_HARASSMENT
            threat = 0.45
            toxicity = 0.88
            confidence = 0.92
            explanations.append("Unsolicited sexually suggestive or exploitative requests detected")

        # Check Social Exclusion / Group Harassment
        elif any(kw in norm_text for kw in self.social_exclusion_keywords):
            category = BullyingCategory.SOCIAL_EXCLUSION
            threat = 0.15
            toxicity = 0.68
            confidence = 0.84
            explanations.append("Systemic social ostracization or group exclusion language")

        # Check Insults / Verbal Bullying
        else:
            insult_matches = [kw for kw in self.insult_keywords if kw in norm_text]
            if insult_matches:
                if len(insult_matches) >= 2 or "kill yourself" in norm_text:
                    category = BullyingCategory.CYBERBULLYING
                    toxicity = min(0.92, 0.65 + 0.10 * len(insult_matches))
                    threat = 0.35 if "kill yourself" in norm_text else 0.18
                    confidence = 0.89
                    explanations.append("Targeted derogatory remarks and harassment keywords")
                    explanations.append(f"Flagged vocabulary matches: {', '.join(insult_matches[:2])}")
                else:
                    category = BullyingCategory.VERBAL_BULLYING
                    toxicity = 0.58
                    threat = 0.10
                    confidence = 0.82
                    explanations.append("Hostile language and disparaging name-calling detected")
            else:
                # Clean text
                category = BullyingCategory.NORMAL
                toxicity = 0.04
                threat = 0.01
                confidence = 0.95
                explanations.append("No toxic or harmful patterns identified in message text")

        return DetectionResult(
            toxicity_score=round(toxicity, 2),
            threat_score=round(threat, 2),
            category=category,
            confidence=round(confidence, 2),
            explanations=explanations,
            model_version=self.model_version,
            detected_language=lang,
            engine_used="OnDevice Engine (Private & Local)"
        )

class CloudDetectionEngine:
    """
    Cloud-based XLM-RoBERTa / LLM-assisted deep contextual analysis engine.
    Used only when explicitly enabled by user consent.
    """
    def __init__(self, simulate_network_failure: bool = False):
        self.model_version = "TraceToxic-XLM-RoBERTa-Cloud-v2.1"
        self.simulate_network_failure = simulate_network_failure
        self.local_engine = OnDeviceDetectionEngine()

    def analyze(self, input_data: DetectionInput) -> DetectionResult:
        if self.simulate_network_failure:
            raise ConnectionError("Cloud inference API unreachable (503 Service Unavailable)")
        
        # Deep analysis simulation: slightly higher resolution on nuanced context
        base_res = self.local_engine.analyze(input_data)
        
        # Fine-tune explanations with deeper contextual flags
        refined_explanations = list(base_res.explanations)
        if base_res.category != BullyingCategory.NORMAL:
            refined_explanations.append("Deep transformer contextual attention confirmed intent")

        return DetectionResult(
            toxicity_score=min(1.0, round(base_res.toxicity_score * 1.05, 2)),
            threat_score=base_res.threat_score,
            category=base_res.category,
            confidence=min(0.99, round(base_res.confidence + 0.04, 2)),
            explanations=refined_explanations,
            model_version=self.model_version,
            detected_language=base_res.detected_language,
            engine_used="Cloud Deep Transformer Engine"
        )

class HybridDetectionEngine:
    """
    Hybrid Detection Engine:
    Attempts cloud inference if enabled; if cloud is unavailable or times out,
    automatically falls back to OnDevice engine seamlessly.
    """
    def __init__(self, allow_cloud: bool = False, cloud_failure_sim: bool = False):
        self.allow_cloud = allow_cloud
        self.on_device = OnDeviceDetectionEngine()
        self.cloud = CloudDetectionEngine(simulate_network_failure=cloud_failure_sim)

    def analyze(self, input_data: DetectionInput) -> DetectionResult:
        if not self.allow_cloud:
            return self.on_device.analyze(input_data)
        
        try:
            return self.cloud.analyze(input_data)
        except Exception as e:
            # Fallback to OnDevice
            res = self.on_device.analyze(input_data)
            fallback_explanations = list(res.explanations)
            fallback_explanations.append(f"[Fallback]: Cloud analysis unavailable ({str(e)}). Processed securely on-device.")
            return DetectionResult(
                toxicity_score=res.toxicity_score,
                threat_score=res.threat_score,
                category=res.category,
                confidence=res.confidence,
                explanations=fallback_explanations,
                model_version=f"{res.model_version} (Fallback)",
                detected_language=res.detected_language,
                engine_used="Hybrid Fallback (Executed On-Device)"
            )
