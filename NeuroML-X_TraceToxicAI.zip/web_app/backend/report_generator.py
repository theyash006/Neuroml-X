"""
PDF Report Generator for TraceToxicAI.
Generates comprehensive, professional digital safety incident reports
with metrics, detected signals, risk timeline, and safety guidance using ReportLab.
"""

import io
import time
from datetime import datetime
from typing import List, Dict, Any
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch

class DigitalSafetyReportGenerator:
    @staticmethod
    def generate_pdf(
        incidents: List[Dict[str, Any]],
        user_name: str = "Anonymous User",
        report_id: str = None
    ) -> bytes:
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=letter,
            rightMargin=40,
            leftMargin=40,
            topMargin=40,
            bottomMargin=40
        )
        
        if not report_id:
            report_id = f"TTAI-{int(time.time())}"
            
        styles = getSampleStyleSheet()
        
        # Custom Typography Styles
        title_style = ParagraphStyle(
            'ReportTitle',
            parent=styles['Normal'],
            fontName='Helvetica-Bold',
            fontSize=22,
            leading=26,
            textColor=colors.HexColor('#1E293B')
        )
        
        subtitle_style = ParagraphStyle(
            'ReportSubtitle',
            parent=styles['Normal'],
            fontName='Helvetica-Bold',
            fontSize=11,
            leading=15,
            textColor=colors.HexColor('#2563EB')
        )
        
        section_heading = ParagraphStyle(
            'SectionHeading',
            parent=styles['Normal'],
            fontName='Helvetica-Bold',
            fontSize=13,
            leading=18,
            textColor=colors.HexColor('#0F172A'),
            spaceAfter=6
        )
        
        body_text = ParagraphStyle(
            'BodyDark',
            parent=styles['Normal'],
            fontName='Helvetica',
            fontSize=9.5,
            leading=14,
            textColor=colors.HexColor('#334155')
        )
        
        evidence_text = ParagraphStyle(
            'EvidenceText',
            parent=styles['Normal'],
            fontName='Helvetica-Oblique',
            fontSize=9,
            leading=13,
            textColor=colors.HexColor('#1E293B')
        )
        
        story = []
        
        # Header block
        story.append(Paragraph("TRACE TOXIC AI", subtitle_style))
        story.append(Paragraph("DIGITAL SAFETY INCIDENT REPORT", title_style))
        story.append(Spacer(1, 8))
        story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor('#2563EB'), spaceAfter=12))
        
        # Meta details table
        now_str = datetime.now().strftime("%B %d, %Y - %H:%M:%S UTC")
        meta_data = [
            [Paragraph(f"<b>Report ID:</b> {report_id}", body_text), Paragraph(f"<b>Generated:</b> {now_str}", body_text)],
            [Paragraph(f"<b>Subject / Account:</b> {user_name}", body_text), Paragraph(f"<b>Protection Status:</b> ACTIVE (Informed Consent Mode)", body_text)]
        ]
        meta_table = Table(meta_data, colWidths=[260, 260])
        meta_table.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#F8FAFC')),
            ('PADDING', (0,0), (-1,-1), 6),
            ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
            ('BOX', (0,0), (-1,-1), 0.5, colors.HexColor('#E2E8F0')),
        ]))
        story.append(meta_table)
        story.append(Spacer(1, 14))
        
        # Incident Summary
        story.append(Paragraph("1. Executive Summary", section_heading))
        total_incidents = len(incidents)
        high_risk_count = sum(1 for i in incidents if i.get("risk_level") in ["HIGH", "CRITICAL"])
        critical_count = sum(1 for i in incidents if i.get("risk_level") == "CRITICAL")
        
        summary_p = (
            f"This confidential digital safety document aggregates and records verified communication notifications "
            f"flagged by the TraceToxicAI client-side monitoring system. A total of <b>{total_incidents}</b> "
            f"harmful interaction(s) were captured across selected communication platforms. "
            f"Of these, <b>{high_risk_count}</b> meet the threshold for High or Critical concern, including <b>{critical_count}</b> "
            f"critical escalation flags. All evidence entries were stored within the user's encrypted device vault."
        )
        story.append(Paragraph(summary_p, body_text))
        story.append(Spacer(1, 12))
        
        # Statistical breakdown table
        story.append(Paragraph("2. Threat & Risk Metrics", section_heading))
        headers = ["Category", "Source App", "Risk Level", "Toxicity", "Threat Score"]
        table_rows = [[Paragraph(f"<b>{h}</b>", body_text) for h in headers]]
        
        for inc in incidents[:8]: # Display up to 8 recent entries in table
            table_rows.append([
                Paragraph(inc.get("category", "N/A"), body_text),
                Paragraph(inc.get("app_source", "N/A"), body_text),
                Paragraph(f"<b>{inc.get('risk_level', 'LOW')}</b> ({inc.get('risk_score', 0)}/100)", body_text),
                Paragraph(f"{int(inc.get('toxicity_score', 0)*100)}%", body_text),
                Paragraph(f"{int(inc.get('threat_score', 0)*100)}%", body_text)
            ])
            
        metrics_table = Table(table_rows, colWidths=[125, 95, 120, 85, 95])
        metrics_table.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#EDF2F7')),
            ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#CBD5E1')),
            ('PADDING', (0,0), (-1,-1), 5),
            ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ]))
        story.append(metrics_table)
        story.append(Spacer(1, 14))
        
        # Detailed Evidence Records
        story.append(Paragraph("3. Documented Evidence Records", section_heading))
        story.append(Paragraph(
            "The following records were preserved with user authorization for formal review by counselors, trusted family contacts, or institutional safety administrators:",
            body_text
        ))
        story.append(Spacer(1, 6))
        
        for idx, inc in enumerate(incidents[:5], 1):
            ts_str = datetime.fromtimestamp(inc.get("timestamp", time.time())).strftime("%Y-%m-%d %H:%M")
            evidence_block = [
                [Paragraph(f"<b>Record #{idx} | Platform:</b> {inc.get('app_source')} | <b>Sender:</b> {inc.get('sender_id')} | <b>Time:</b> {ts_str}", body_text)],
                [Paragraph(f'<b>Extracted Text:</b> "{inc.get("message_text")}"', evidence_text)],
                [Paragraph(f"<b>AI Assessment:</b> Category: {inc.get('category')} | Confidence: {int(inc.get('ai_confidence', 0)*100)}%", body_text)],
                [Paragraph(f"<b>Signals:</b> {'; '.join(inc.get('explanations', ['Harmful language pattern']))}", body_text)]
            ]
            if inc.get("detected_patterns"):
                evidence_block.append([Paragraph(f"<b>Pattern Alert:</b> {'; '.join(inc.get('detected_patterns'))}", body_text)])
                
            e_table = Table(evidence_block, colWidths=[520])
            e_table.setStyle(TableStyle([
                ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#F8FAFC')),
                ('BOX', (0,0), (-1,-1), 0.5, colors.HexColor('#94A3B8')),
                ('PADDING', (0,0), (-1,-1), 4),
            ]))
            story.append(e_table)
            story.append(Spacer(1, 8))
            
        story.append(Spacer(1, 8))
        
        # Recommended Safety Guidance
        story.append(Paragraph("4. Recommended Safety & Preservation Steps", section_heading))
        guidance = [
            "• <b>Preserve Original Context:</b> Keep these records intact in the encrypted vault. Do not modify or alter timestamps.",
            "• <b>Avoid Aggressive Retaliation:</b> Do not engage in retaliatory threats or insults, which may escalate the harassment cycle.",
            "• <b>In-App Controls:</b> Restrict or block abusive accounts directly inside the originating application (WhatsApp / Instagram / Discord).",
            "• <b>Consult Trusted Support:</b> If risk remains High or Critical, share this official report directly with a counselor, trusted guardian, or student grievance authority.",
            "• <b>Emergency Escalation:</b> If physical safety is in immediate jeopardy, consult local emergency authorities immediately."
        ]
        for g in guidance:
            story.append(Paragraph(g, body_text))
            story.append(Spacer(1, 3))
            
        story.append(Spacer(1, 14))
        story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#CBD5E1'), spaceAfter=8))
        disclaimer = (
            "Disclaimer: TraceToxicAI provides automated linguistic analysis and risk estimation tools based on client-side "
            "notification inputs with informed user consent. Assessments do not constitute legal determinations of culpability."
        )
        story.append(Paragraph(disclaimer, ParagraphStyle('Disc', parent=styles['Normal'], fontSize=7.5, leading=10, textColor=colors.HexColor('#64748B'))))
        
        doc.build(story)
        pdf_bytes = buffer.getvalue()
        buffer.close()
        return pdf_bytes
