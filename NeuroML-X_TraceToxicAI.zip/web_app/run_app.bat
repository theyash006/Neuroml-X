@echo off
echo ===================================================
echo Starting TraceToxicAI - Streamlit Application
echo ===================================================
cd /d "%~dp0"
streamlit run app.py --server.port=8501 --server.headless=false
pause
