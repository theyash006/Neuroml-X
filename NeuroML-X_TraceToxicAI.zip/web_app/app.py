"""
TraceToxicAI — Intelligent Cyberbullying Detection and Digital Safety System
Interactive Streamlit Application showcasing full End-to-End Native Architecture:
- Explicit Informed Consent & Mandatory Notification Access Gate
- Minor Mode (<18 with Guardian Link) vs Adult Mode (>=18 with Trusted Contacts)
- Multilingual NLP Engine (English, Hindi, Punjabi, Hinglish) with OnDevice/Cloud/Hybrid fallback
- Pre-Analysis Sensitive Data Filtering (OTP, Banking, 2FA)
- Real-time Multidimensional Risk & Pattern Engine (Repetition, Multi-sender, Escalation)
- Human Review & Accuracy Feedback Loop
- AES-GCM Encrypted Evidence Vault with PIN protection & Data Retention policies
- Non-Autonomous Safety Guidance & Manual SOS trigger
- Professional PDF Incident Report Generator
"""

import streamlit as st
import pandas as pd
import numpy as np
import time
from datetime import datetime, date
import plotly.express as px
import plotly.graph_objects as go
import uuid
import sys
import os

# Ensure backend modules are on sys.path
current_dir = os.path.dirname(os.path.abspath(__file__))
backend_dir = os.path.join(current_dir, "backend")
if backend_dir not in sys.path:
    sys.path.append(backend_dir)

from sensitive_filter import SensitiveDataFilter
from nlp_engine import (
    DetectionInput, DetectionResult, BullyingCategory,
    OnDeviceDetectionEngine, CloudDetectionEngine, HybridDetectionEngine,
    LanguageDetector
)
from risk_engine import RiskCalculator, RiskLevel, IncidentRecord
from vault_crypto import EvidenceVault
from report_generator import DigitalSafetyReportGenerator

# --- Page Configuration ---
st.set_page_config(
    page_title="TraceToxicAI — Digital Safety System",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- Custom Styling for Calm, Trustworthy Professional UX ---
st.markdown("""
<style>
    /* Calm modern theme */
    .main-header {
        font-family: 'Inter', -apple-system, sans-serif;
        font-weight: 700;
        color: #1E293B;
        margin-bottom: 2px;
    }
    .sub-header {
        font-size: 14px;
        color: #64748B;
        margin-bottom: 18px;
    }
    .status-badge-active {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 9999px;
        background-color: #ECFDF5;
        color: #059669;
        font-weight: 600;
        font-size: 13px;
        border: 1px solid #A7F3D0;
    }
    .metric-card {
        background-color: #FFFFFF;
        border-radius: 12px;
        padding: 16px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04);
        border: 1px solid #F1F5F9;
    }
    .incident-card {
        background-color: #F8FAFC;
        border-left: 4px solid #3B82F6;
        padding: 14px;
        border-radius: 8px;
        margin-bottom: 12px;
    }
    .incident-critical {
        border-left: 4px solid #EF4444;
        background-color: #FEF2F2;
    }
    .incident-high {
        border-left: 4px solid #F97316;
        background-color: #FFF7ED;
    }
    .incident-moderate {
        border-left: 4px solid #F59E0B;
        background-color: #FFFBEB;
    }
</style>
""", unsafe_allow_html=True)

# --- Session State Initialization ---
if "user_authenticated" not in st.session_state:
    st.session_state.user_authenticated = True  # Demo session enabled
if "consent_granted" not in st.session_state:
    st.session_state.consent_granted = False
if "notification_access_enabled" not in st.session_state:
    st.session_state.notification_access_enabled = False
if "user_dob" not in st.session_state:
    st.session_state.user_dob = date(2008, 5, 15) # Default ~18 yr demo
if "user_age" not in st.session_state:
    st.session_state.user_age = 18
if "age_mode" not in st.session_state:
    st.session_state.age_mode = "Minor Mode (<18)"
if "selected_apps" not in st.session_state:
    st.session_state.selected_apps = ["WhatsApp", "Instagram", "Discord", "Telegram"]
if "engine_mode" not in st.session_state:
    st.session_state.engine_mode = "OnDevice Engine (Private & Local)"
if "vault_pin" not in st.session_state:
    st.session_state.vault_pin = "1234"
if "vault_unlocked" not in st.session_state:
    st.session_state.vault_unlocked = False
if "retention_policy" not in st.session_state:
    st.session_state.retention_policy = "30_days"
if "history_incidents" not in st.session_state:
    st.session_state.history_incidents = []
if "vault_records" not in st.session_state:
    st.session_state.vault_records = []
if "total_analyzed_count" not in st.session_state:
    st.session_state.total_analyzed_count = 0
if "feedback_log" not in st.session_state:
    st.session_state.feedback_log = []
if "guardian_contact" not in st.session_state:
    st.session_state.guardian_contact = {"name": "Guardian / Parent", "contact": "+1 (555) 019-2834", "linked": True}

# --- Service Instances ---
sensitive_filter = SensitiveDataFilter()
on_device_engine = OnDeviceDetectionEngine()
cloud_engine = CloudDetectionEngine()
hybrid_engine = HybridDetectionEngine(allow_cloud=True)
risk_calculator = RiskCalculator()
vault = EvidenceVault(storage_dir=os.path.join(current_dir, "vault_store"))

# --- Top Navigation Bar & Brand ---
col_head1, col_head2 = st.columns([3, 1])
with col_head1:
    st.markdown("<h2 class='main-header'>🛡️ TRACE TOXIC AI</h2>", unsafe_allow_html=True)
    st.markdown("<p class='sub-header'>Intelligent Cyberbullying Detection and Personal Digital Safety System</p>", unsafe_allow_html=True)
with col_head2:
    if st.session_state.notification_access_enabled:
        st.markdown("<div style='text-align: right; padding-top: 10px;'><span class='status-badge-active'>● ACTIVE PROTECTION</span></div>", unsafe_allow_html=True)
    else:
        st.markdown("<div style='text-align: right; padding-top: 10px;'><span style='color: #DC2626; font-weight: 600;'>● ACCESS REQUIRED</span></div>", unsafe_allow_html=True)

# --- Sidebar Navigation ---
st.sidebar.title("Navigation")
menu_choice = st.sidebar.radio(
    "Go to",
    [
        "1. Consent & Notification Gate",
        "2. Age & Profile Setup",
        "3. Live Ingestion Simulator",
        "4. Safety Dashboard",
        "5. Human Incident Review",
        "6. Encrypted Evidence Vault",
        "7. PDF Report Generator",
        "8. SOS & Safety Guidance"
    ]
)

st.sidebar.markdown("---")
st.sidebar.subheader("System Configuration")
st.sidebar.caption("Processing Mode:")
selected_engine = st.sidebar.selectbox(
    "NLP Execution Engine",
    ["OnDevice (Private & Local)", "Cloud (Deep Context)", "Hybrid (Cloud with Local Fallback)"],
    index=0
)
st.session_state.engine_mode = selected_engine

st.sidebar.caption("Age Category:")
st.sidebar.info(f"**{st.session_state.age_mode}** (Age: {st.session_state.user_age})")

# =====================================================================
# SCREEN 1: CONSENT & NOTIFICATION ACCESS HARD GATE
# =====================================================================
if menu_choice == "1. Consent & Notification Gate":
    st.subheader("📋 Step 1: Informed Consent & Hard Permission Gate")
    st.info("In compliance with strict Android privacy guidelines, TraceToxicAI cannot and will not analyze communications without your explicit, granular consent.")

    with st.container():
        st.markdown("#### Transparency Disclosure")
        st.markdown("""
        Before granting notification listener access, please review how TraceToxicAI protects your privacy:
        - **Monitored Applications:** Analysis runs **only** on applications you explicitly check below.
        - **Sensitive Non-Message Data Dropped:** Verification codes, OTPs, 2FA tokens, and banking transaction notifications are instantly filtered and **never** processed by AI models.
        - **On-Device First:** Linguistic parsing runs locally on your device by default. Cloud inference is strictly optional.
        - **Data Ownership:** Flagged incidents are stored locally in an **AES-GCM-256 encrypted vault**. You can delete individual records or set automatic 7/30-day retention wipes at any time.
        - **Zero Autonomous External Actions:** The system will **never** automatically call, message, email, or report anyone without your direct confirmation button.
        """)

        st.markdown("#### Select Applications to Monitor")
        col_app1, col_app2 = st.columns(2)
        with col_app1:
            app_wa = st.checkbox("WhatsApp Messenger", value="WhatsApp" in st.session_state.selected_apps)
            app_ig = st.checkbox("Instagram Direct", value="Instagram" in st.session_state.selected_apps)
            app_dc = st.checkbox("Discord", value="Discord" in st.session_state.selected_apps)
            app_tg = st.checkbox("Telegram", value="Telegram" in st.session_state.selected_apps)
        with col_app2:
            app_bnk = st.checkbox("Banking / Payment Apps (Blocked by Policy)", value=False, disabled=True, help="Security policy permanently excludes financial apps.")
            app_shp = st.checkbox("Shopping Apps (Blocked by Policy)", value=False, disabled=True)
            app_sys = st.checkbox("System Notifications (Blocked by Policy)", value=False, disabled=True)

        new_apps = []
        if app_wa: new_apps.append("WhatsApp")
        if app_ig: new_apps.append("Instagram")
        if app_dc: new_apps.append("Discord")
        if app_tg: new_apps.append("Telegram")
        st.session_state.selected_apps = new_apps

        st.markdown("---")
        st.markdown("#### Android NotificationListenerService Verification")
        st.caption("On native Android, this corresponds to checking `NotificationManagerCompat.getEnabledListenerPackages()`.")
        
        col_perm1, col_perm2 = st.columns([2, 1])
        with col_perm1:
            st.write(f"**Selected Apps ({len(st.session_state.selected_apps)}):** {', '.join(st.session_state.selected_apps) if st.session_state.selected_apps else 'None'}")
            st.write(f"**Consent Status:** {'✅ Granted' if st.session_state.consent_granted else '❌ Pending Confirmation'}")
            st.write(f"**System Access Status:** {'🟢 Enabled (Active)' if st.session_state.notification_access_enabled else '🔴 Disabled'}")
        with col_perm2:
            if not st.session_state.notification_access_enabled:
                if st.button("Simulate: Grant Notification Access", type="primary"):
                    if len(st.session_state.selected_apps) == 0:
                        st.error("Please select at least one application to monitor before enabling access.")
                    else:
                        st.session_state.consent_granted = True
                        st.session_state.notification_access_enabled = True
                        st.success("Android Notification Access successfully enabled!")
                        st.rerun()
            else:
                if st.button("Revoke Access (Disconnect)"):
                    st.session_state.notification_access_enabled = False
                    st.session_state.consent_granted = False
                    st.warning("Notification listener disconnected. Protection paused.")
                    st.rerun()

# =====================================================================
# SCREEN 2: AGE & PROFILE SETUP (MINOR VS ADULT MODE)
# =====================================================================
elif menu_choice == "2. Age & Profile Setup":
    st.subheader("👤 Step 2: Age-Based Profile & Guardian Settings")
    st.markdown("""
    TraceToxicAI personalizes its safety workflows according to user age.
    - **Minor Mode (< 18):** Provides an optional, transparent **Parent / Guardian Connection** with mutual visibility (no hidden surveillance).
    - **Adult Mode (18+):** Enables custom trusted contacts (counselors, friends, support hotlines).
    """)

    col_dob1, col_dob2 = st.columns(2)
    with col_dob1:
        selected_dob = st.date_input(
            "Enter Date of Birth (DOB)",
            value=st.session_state.user_dob,
            min_value=date(1940, 1, 1),
            max_value=date.today()
        )
        # Calculate Age
        today = date.today()
        age = today.year - selected_dob.year - ((today.month, today.day) < (selected_dob.month, selected_dob.day))
        st.session_state.user_dob = selected_dob
        st.session_state.user_age = age
        st.session_state.age_mode = "Minor Mode (<18)" if age < 18 else "Adult Mode (18+)"

    with col_dob2:
        st.markdown(f"### Detected Tier: **{st.session_state.age_mode}**")
        st.write(f"Calculated Age: **{age} years old**")
        if age < 18:
            st.warning("🛡️ Minor Mode active: Protective guidance, evidence preservation, and guardian invite options enabled.")
        else:
            st.success("🛡️ Adult Mode active: Self-advocacy tools, direct report generation, and trusted contact network enabled.")

    st.markdown("---")
    if age < 18:
        st.markdown("#### Optional Guardian / Parent Connection (Minor Mode)")
        st.caption("Requirements: The guardian must accept an explicit invitation. Relationship is completely transparent to the user; no secret surveillance.")
        col_g1, col_g2 = st.columns(2)
        with col_g1:
            g_name = st.text_input("Guardian Name", value=st.session_state.guardian_contact["name"])
            g_phone = st.text_input("Guardian Phone / Email", value=st.session_state.guardian_contact["contact"])
        with col_g2:
            st.write("**Guardian Sharing Permissions:**")
            st.checkbox("Share Monthly Safety Summary", value=True)
            st.checkbox("Alert Guardian on Confirmed Critical Threat Incidents (Requires Confirmation)", value=True)
            st.checkbox("Expose Uncensored Private Chat Transcripts", value=False, disabled=True, help="Privacy Policy: Raw private chat text is never automatically exposed to guardians.")
            if st.button("Send / Update Guardian Invitation"):
                st.session_state.guardian_contact = {"name": g_name, "contact": g_phone, "linked": True}
                st.success(f"Guardian invitation verified for {g_name} ({g_phone}). Mutual visibility established.")
    else:
        st.markdown("#### Trusted Emergency Contacts (Adult Mode)")
        st.caption("You can add friends, legal advisors, or local counselors to your rapid-contact safety list.")
        st.text_input("Contact Name", value="Campus Counseling Hotline")
        st.text_input("Contact Phone / Support URL", value="+1 (800) 273-8255")
        st.button("Save Trusted Contact")

# =====================================================================
# SCREEN 3: LIVE INGESTION SIMULATOR & REAL-TIME PIPELINE
# =====================================================================
elif menu_choice == "3. Live Ingestion Simulator":
    st.subheader("⚡ Step 3: Ingestion Pipeline Simulator")
    
    if not st.session_state.notification_access_enabled:
        st.error("⚠️ Notification Access is currently disabled. Please go to **'1. Consent & Notification Gate'** to enable access before testing ingestion.")
    else:
        st.markdown("Simulate incoming notifications from selected Android communication apps and observe the real-time processing pipeline.")

        # Preset test scenarios
        presets = {
            "Custom Input": ("", "WhatsApp", "custom_sender"),
            "[English Threat] Physical Harm Threat": ("I know where you live and I will find you and beat you up.", "WhatsApp", "Alex_Bully"),
            "[Hindi Threat & Insult] Devanagari Threat": ("तुझे जान से मार दूंगा, बच के रहना तू और तेरी फैमिली", "Instagram", "Rohan_99"),
            "[Punjabi Threat] Gurmukhi Severe Threat": ("ਤੈਨੂੰ ਜਾਨੋਂ ਮਾਰ ਦਿਆਂਗਾ, ਘਰ ਆ ਕੇ ਕੁੱਟਾਂਗਾ ਤੈਨੂੰ", "Telegram", "Harpreet_X"),
            "[Hinglish Harassment] Toxic Insults": ("Tu bohot bada loser aur kutta hai, group se bahar nikal", "Discord", "ToxicUser_Alpha"),
            "[Blackmail / Coercion] Extortion Attempt": ("Pay me 500 dollars right now or I will leak your photos to everyone", "Instagram", "UnknownBlackmailer"),
            "[Sensitive Data] Bank OTP Alert (Must be Dropped)": ("Your HDFC Bank OTP is 849201 for Rs 5,400 transaction at Amazon. Do not share.", "WhatsApp", "HDFCBANK"),
            "[Normal Conversation] Clean Friendly Message": ("Hey buddy, are we still meeting in the library at 4 PM for project work?", "Discord", "Sarah_StudyBuddy"),
            "[Social Exclusion] Group Ostracization": ("Nobody likes you here. Stop texting us and get out of this group loser.", "WhatsApp", "CoolKids_Group")
        }

        selected_preset = st.selectbox("Select a Preset Test Scenario or Choose Custom", list(presets.keys()))
        default_text, default_app, default_sender = presets[selected_preset]

        col_in1, col_in2 = st.columns([3, 1])
        with col_in1:
            msg_text = st.text_area("Simulated Notification Message Text", value=default_text, height=100)
        with col_in2:
            msg_app = st.selectbox("Originating App", ["WhatsApp", "Instagram", "Discord", "Telegram", "BankingApp"], index=0 if default_app not in ["Instagram", "Discord", "Telegram"] else ["WhatsApp", "Instagram", "Discord", "Telegram", "BankingApp"].index(default_app))
            msg_sender = st.text_input("Sender Handle / ID", value=default_sender)

        if st.button("🚀 Ingest & Process Notification", type="primary"):
            if not msg_text.strip():
                st.warning("Please enter a message to analyze.")
            else:
                st.session_state.total_analyzed_count += 1
                now_ts = time.time()
                
                st.markdown("---")
                st.markdown("### Ingestion Pipeline Execution Trace")

                # Step A: App Selection Filter
                step_col1, step_col2, step_col3, step_col4 = st.columns(4)
                
                is_app_selected = msg_app in st.session_state.selected_apps
                with step_col1:
                    st.markdown("**1. App Filter**")
                    if is_app_selected:
                        st.success(f"Passed: '{msg_app}' is in user whitelist")
                    else:
                        st.error(f"Blocked: '{msg_app}' not selected by user")

                if not is_app_selected:
                    st.warning("Notification ignored because source app is not monitored. Processing halted.")
                else:
                    # Step B: Sensitive Data Filter
                    is_sens, sens_reason = sensitive_filter.is_sensitive(msg_text)
                    with step_col2:
                        st.markdown("**2. Sensitive Filter**")
                        if is_sens:
                            st.warning(f"DROPPED: {sens_reason}")
                        else:
                            st.success("Clean: No financial/OTP data detected")

                    if is_sens:
                        st.info("🔒 **Privacy Preservation**: Sensitive data notification was dropped immediately before reaching any AI model. Zero NLP inference executed.")
                    else:
                        # Step C: Deduplication Check
                        is_dup = risk_calculator.deduplicator.is_duplicate(msg_text, msg_sender, msg_app, now_ts)
                        with step_col3:
                            st.markdown("**3. Deduplication**")
                            if is_dup:
                                st.warning("Duplicate Detected (Window: 60s)")
                            else:
                                st.success("Unique notification event")

                        # Step D: NLP Analysis
                        with step_col4:
                            st.markdown("**4. Detection Engine**")
                            st.caption(f"Mode: {st.session_state.engine_mode}")
                        
                        det_input = DetectionInput(
                            message_text=msg_text,
                            sender_id=msg_sender,
                            app_source=msg_app,
                            timestamp=now_ts
                        )

                        if "OnDevice" in st.session_state.engine_mode:
                            det_res = on_device_engine.analyze(det_input)
                        elif "Cloud" in st.session_state.engine_mode:
                            det_res = cloud_engine.analyze(det_input)
                        else:
                            det_res = hybrid_engine.analyze(det_input)

                        # Step E: Risk Engine Calculation
                        risk_score, risk_lvl, patterns = risk_calculator.calculate_risk(
                            det_res.toxicity_score,
                            det_res.threat_score,
                            det_res.category.value,
                            msg_sender,
                            st.session_state.history_incidents
                        )

                        # Build Incident Record
                        inc_rec = IncidentRecord(
                            incident_id=f"INC-{str(uuid.uuid4())[:8].upper()}",
                            timestamp=now_ts,
                            app_source=msg_app,
                            sender_id=msg_sender,
                            message_text=msg_text,
                            category=det_res.category.value,
                            toxicity_score=det_res.toxicity_score,
                            threat_score=det_res.threat_score,
                            ai_confidence=det_res.confidence,
                            risk_score=risk_score,
                            risk_level=risk_lvl,
                            detected_patterns=patterns,
                            explanations=det_res.explanations,
                            status="PENDING_REVIEW" if det_res.category != BullyingCategory.NORMAL else "CLEAN"
                        )
                        
                        st.session_state.history_incidents.append(inc_rec)

                        # Render Results
                        st.markdown("---")
                        st.markdown("### Analysis Findings")

                        res_col1, res_col2, res_col3, res_col4 = st.columns(4)
                        res_col1.metric("Category", inc_rec.category)
                        res_col2.metric("AI Confidence", f"{int(inc_rec.ai_confidence * 100)}%")
                        res_col3.metric("Toxicity Score", f"{int(inc_rec.toxicity_score * 100)}%")
                        res_col4.metric("Risk Score", f"{inc_rec.risk_score} / 100 ({inc_rec.risk_level.value})")

                        # Explanations
                        st.markdown("**AI Detection Explanations:**")
                        for exp in inc_rec.explanations:
                            st.markdown(f"- {exp}")
                        
                        if inc_rec.detected_patterns:
                            st.markdown("**Historical Pattern Alerts:**")
                            for pat in inc_rec.detected_patterns:
                                st.markdown(f"⚠️ *{pat}*")

                        if inc_rec.category != "NORMAL":
                            st.info("Incident queued for **Human Review**. Head over to '5. Human Incident Review' or '4. Safety Dashboard'.")

# =====================================================================
# SCREEN 4: SAFETY DASHBOARD
# =====================================================================
elif menu_choice == "4. Safety Dashboard":
    st.subheader("📊 Digital Safety Dashboard")

    total_analyzed = st.session_state.total_analyzed_count
    incidents = [i for i in st.session_state.history_incidents if i.category != "NORMAL"]
    high_risk_incidents = [i for i in incidents if i.risk_level in [RiskLevel.HIGH, RiskLevel.CRITICAL]]
    saved_vault_count = len(st.session_state.vault_records)

    # Top Metrics
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Notifications Analyzed", total_analyzed)
    m2.metric("Harmful Incidents Flagged", len(incidents))
    m3.metric("High / Critical Risk", len(high_risk_incidents))
    m4.metric("Preserved in Vault", saved_vault_count)

    st.markdown("---")

    col_chart, col_recent = st.columns([3, 2])
    with col_chart:
        st.markdown("#### Risk Timeline")
        if incidents:
            df = pd.DataFrame([
                {
                    "Time": datetime.fromtimestamp(i.timestamp).strftime("%H:%M:%S"),
                    "Risk Score": i.risk_score,
                    "Sender": i.sender_id,
                    "Category": i.category,
                    "Risk Level": i.risk_level.value
                } for i in incidents
            ])
            fig = px.line(df, x="Time", y="Risk Score", markers=True, color="Risk Level",
                          color_discrete_map={"LOW": "#10B981", "MODERATE": "#F59E0B", "HIGH": "#F97316", "CRITICAL": "#EF4444"},
                          title="Recent Risk Progression Timeline")
            fig.update_layout(yaxis_range=[0, 105], height=320, margin=dict(l=20, r=20, t=40, b=20))
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No harmful incidents recorded yet. All communications within normal thresholds.")

    with col_recent:
        st.markdown("#### Recent Incidents")
        if incidents:
            for inc in reversed(incidents[-4:]):
                card_class = "incident-card"
                if inc.risk_level == RiskLevel.CRITICAL: card_class += " incident-critical"
                elif inc.risk_level == RiskLevel.HIGH: card_class += " incident-high"
                elif inc.risk_level == RiskLevel.MODERATE: card_class += " incident-moderate"

                st.markdown(f"""
                <div class='{card_class}'>
                    <b>{inc.category}</b> &nbsp;|&nbsp; <span style='font-size: 12px;'>From: {inc.sender_id} ({inc.app_source})</span><br/>
                    <small>"{inc.message_text[:60]}{'...' if len(inc.message_text)>60 else ''}"</small><br/>
                    <span style='font-weight: 600;'>Risk: {inc.risk_level.value} ({inc.risk_score}/100)</span>
                </div>
                """, unsafe_allow_html=True)
        else:
            st.caption("No recent incidents.")

# =====================================================================
# SCREEN 5: HUMAN INCIDENT REVIEW & FEEDBACK
# =====================================================================
elif menu_choice == "5. Human Incident Review":
    st.subheader("🧐 Step 5: Incident Review & Accuracy Feedback")
    st.markdown("""
    In TraceToxicAI, **you** remain in complete control.
    AI detections are suggestions—review each flagged communication, confirm whether it was harmful,
    and choose whether to store it in your encrypted vault.
    """)

    pending = [i for i in st.session_state.history_incidents if i.status == "PENDING_REVIEW"]

    if not pending:
        st.success("🎉 All caught up! No incidents pending review.")
    else:
        st.write(f"**{len(pending)} Incident(s) Awaiting Review**")
        for inc in pending:
            with st.expander(f"⚠️ {inc.category} from {inc.sender_id} via {inc.app_source} [Risk: {inc.risk_level.value}]", expanded=True):
                st.markdown(f"**Message:** *\"{inc.message_text}\"*")
                col_d1, col_d2, col_d3 = st.columns(3)
                col_d1.write(f"**Toxicity:** {int(inc.toxicity_score * 100)}%")
                col_d2.write(f"**Threat Score:** {int(inc.threat_score * 100)}%")
                col_d3.write(f"**Risk Level:** {inc.risk_level.value} ({inc.risk_score}/100)")

                st.write("**Signals Detected:**")
                for exp in inc.explanations:
                    st.write(f"- {exp}")
                if inc.detected_patterns:
                    for pat in inc.detected_patterns:
                        st.write(f"- ⚠️ {pat}")

                st.markdown("---")
                st.write("**Was this detection accurate?**")
                col_fb1, col_fb2, col_fb3 = st.columns(3)
                with col_fb1:
                    fb_correct = st.radio(f"Feedback for {inc.incident_id}", ["👍 Accurate Detection", "👎 Misunderstanding / False Positive"], key=f"fb_{inc.incident_id}")
                with col_fb2:
                    fb_reason = st.selectbox("Reason (optional)", ["None", "Friendly banter/joke", "Misunderstood slang/context", "Not targeted at me", "Quoting someone else"], key=f"reas_{inc.incident_id}")

                st.markdown("---")
                col_act1, col_act2, col_act3 = st.columns(3)
                with col_act1:
                    if st.button("💾 Keep as Evidence (Save to Vault)", key=f"save_{inc.incident_id}", type="primary"):
                        inc.status = "SAVED_VAULT"
                        rec_dict = {
                            "incident_id": inc.incident_id,
                            "timestamp": inc.timestamp,
                            "app_source": inc.app_source,
                            "sender_id": inc.sender_id,
                            "message_text": inc.message_text,
                            "category": inc.category,
                            "toxicity_score": inc.toxicity_score,
                            "threat_score": inc.threat_score,
                            "ai_confidence": inc.ai_confidence,
                            "risk_score": inc.risk_score,
                            "risk_level": inc.risk_level.value,
                            "detected_patterns": inc.detected_patterns,
                            "explanations": inc.explanations
                        }
                        st.session_state.vault_records.append(rec_dict)
                        # Encrypt to disk
                        vault.save_incidents(st.session_state.vault_records, st.session_state.vault_pin)
                        st.success(f"Incident {inc.incident_id} saved to AES-GCM Encrypted Vault.")
                        st.rerun()
                with col_act2:
                    if st.button("🗑️ Dismiss Incident", key=f"dism_{inc.incident_id}"):
                        inc.status = "DISMISSED"
                        st.info(f"Incident {inc.incident_id} dismissed.")
                        st.rerun()
                with col_act3:
                    if st.button("⏳ Review Later", key=f"later_{inc.incident_id}"):
                        st.caption("Postponed for later review.")

# =====================================================================
# SCREEN 6: ENCRYPTED EVIDENCE VAULT
# =====================================================================
elif menu_choice == "6. Encrypted Evidence Vault":
    st.subheader("🔐 Step 6: Encrypted Evidence Vault")
    st.markdown("""
    Evidence records are secured locally on your device with **AES-GCM-256 authenticated encryption**.
    Keys are derived from your private PIN using PBKDF2 with 100,000 iterations.
    """)

    col_pin1, col_pin2 = st.columns([1, 2])
    with col_pin1:
        pin_input = st.text_input("Enter Vault PIN (Default: 1234)", type="password")
        if st.button("Unlock Vault"):
            if pin_input == st.session_state.vault_pin:
                st.session_state.vault_unlocked = True
                st.success("Vault unlocked successfully!")
            else:
                st.error("Incorrect PIN. Decryption failed.")

    with col_pin2:
        st.markdown("#### Vault Retention Policy")
        ret_policy = st.selectbox(
            "Automatic Data Retention Policy",
            ["30_days", "7_days", "never"],
            index=["30_days", "7_days", "never"].index(st.session_state.retention_policy)
        )
        if ret_policy != st.session_state.retention_policy:
            st.session_state.retention_policy = ret_policy
            st.session_state.vault_records = vault.enforce_retention(st.session_state.vault_records, ret_policy)
            vault.save_incidents(st.session_state.vault_records, st.session_state.vault_pin)
            st.info(f"Retention policy updated to: {ret_policy}")

    st.markdown("---")
    if st.session_state.vault_unlocked:
        st.markdown(f"### Preserved Records ({len(st.session_state.vault_records)})")
        if not st.session_state.vault_records:
            st.caption("No records preserved in the vault yet.")
        else:
            for idx, rec in enumerate(st.session_state.vault_records):
                dt_str = datetime.fromtimestamp(rec["timestamp"]).strftime("%Y-%m-%d %H:%M:%S")
                with st.container():
                    st.markdown(f"""
                    **Record #{idx+1} ({rec['incident_id']})** &nbsp;|&nbsp; Platform: `{rec['app_source']}` &nbsp;|&nbsp; Sender: `{rec['sender_id']}` &nbsp;|&nbsp; Recorded: `{dt_str}`<br/>
                    Category: **{rec['category']}** &nbsp;|&nbsp; Risk: **{rec['risk_level']} ({rec['risk_score']}/100)**<br/>
                    *\"{rec['message_text']}\"*
                    """, unsafe_allow_html=True)
                    col_del, _ = st.columns([1, 4])
                    with col_del:
                        if st.button("Delete Entry", key=f"del_{rec['incident_id']}"):
                            st.session_state.vault_records.pop(idx)
                            vault.save_incidents(st.session_state.vault_records, st.session_state.vault_pin)
                            st.warning("Entry deleted.")
                            st.rerun()
                    st.markdown("---")
    else:
        st.warning("Vault is currently locked. Enter your PIN to view decrypted evidence records.")

# =====================================================================
# SCREEN 7: PDF REPORT GENERATOR
# =====================================================================
elif menu_choice == "7. PDF Report Generator":
    st.subheader("📄 Step 7: Digital Safety Incident PDF Report")
    st.markdown("""
    Generate an official, professional digital safety report for school counselors, trusted guardians,
    or administrative reporting.
    """)

    report_user = st.text_input("User / Case Name", value="Digital Safety Case #402")
    
    records_to_report = st.session_state.vault_records
    if not records_to_report and st.session_state.history_incidents:
        # Fallback to current session incidents if vault is empty
        records_to_report = [
            {
                "incident_id": i.incident_id,
                "timestamp": i.timestamp,
                "app_source": i.app_source,
                "sender_id": i.sender_id,
                "message_text": i.message_text,
                "category": i.category,
                "toxicity_score": i.toxicity_score,
                "threat_score": i.threat_score,
                "ai_confidence": i.ai_confidence,
                "risk_score": i.risk_score,
                "risk_level": i.risk_level.value,
                "detected_patterns": i.detected_patterns,
                "explanations": i.explanations
            }
            for i in st.session_state.history_incidents if i.category != "NORMAL"
        ]

    st.write(f"Incidents included in this report: **{len(records_to_report)}**")

    if st.button("Generate Professional PDF Report", type="primary"):
        if not records_to_report:
            st.error("No flagged incidents available to generate a report.")
        else:
            with st.spinner("Compiling ReportLab PDF document..."):
                pdf_data = DigitalSafetyReportGenerator.generate_pdf(
                    incidents=records_to_report,
                    user_name=report_user
                )
                st.success("Official PDF Digital Safety Report generated successfully!")
                st.download_button(
                    label="⬇️ Download Digital Safety Report (PDF)",
                    data=pdf_data,
                    file_name=f"TraceToxicAI_Incident_Report_{int(time.time())}.pdf",
                    mime="application/pdf"
                )

# =====================================================================
# SCREEN 8: SOS & SAFETY GUIDANCE (NON-AUTONOMOUS)
# =====================================================================
elif menu_choice == "8. SOS & Safety Guidance":
    st.subheader("🆘 Step 8: Safety Guidance & Emergency SOS")
    
    st.markdown("""
    > [!IMPORTANT]
    > **Zero Autonomous Actions Policy**: TraceToxicAI will **NEVER** silently contact parents, school officials, or emergency services without your explicit confirmation.
    """)

    col_sos1, col_sos2 = st.columns(2)
    with col_sos1:
        st.markdown("### Rapid Contact Center")
        if st.session_state.age_mode == "Minor Mode (<18)":
            target_name = st.session_state.guardian_contact["name"]
            target_info = st.session_state.guardian_contact["contact"]
        else:
            target_name = "Campus Counselor / Trusted Contact"
            target_info = "+1 (800) 273-8255"

        st.write(f"Configured Recipient: **{target_name}** ({target_info})")

        # Explicit confirmation required
        st.warning("Triggering SOS will prepare a dialer intent / message draft on your device. You must confirm the transmission.")
        confirm_sos = st.checkbox("I explicitly authorize preparing an emergency contact alert.")
        
        if st.button("🚨 Prepare SOS Alert", type="primary", disabled=not confirm_sos):
            st.success(f"Emergency SOS prepared for {target_name}. In native Android, this launches `Intent.ACTION_DIAL` or opens WhatsApp draft with user confirmation.")

    with col_sos2:
        st.markdown("### Recommended Digital Safety Actions")
        st.markdown("""
        1. **Preserve Evidence:** Keep entries in your encrypted vault. Do not delete screenshots or message notifications.
        2. **Do Not Retaliate:** Engaging in retaliatory arguments can increase the risk of escalating aggression.
        3. **In-App Blocking:** Use WhatsApp / Instagram built-in 'Block & Report' tools on the abusive account.
        4. **Confidential Discussion:** Speak to a trusted adult, counselor, or helpline.
        5. **Helpline Numbers:**
           - Cyberbullying Prevention Line: 1-800-273-TALK
           - Crisis Text Line: Text HOME to 741741
        """)
