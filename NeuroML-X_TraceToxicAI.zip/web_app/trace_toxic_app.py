import io
import os
import re
import sys
from datetime import datetime
import xml.sax.saxutils as saxutils

import numpy as np
import plotly.graph_objects as go
import streamlit as st
import torch
from dotenv import load_dotenv

# ------------------------------------------------------------
# COMPATIBILITY PATCH FOR TRANSFORMERS & PYTORCH
# ------------------------------------------------------------
# In transformers >= 4.49, check_torch_load_is_safe enforces torch >= 2.6
# when loading non-safetensors checkpoints (like j-hartmann emotion model).
# We safely monkeypatch this to ensure smooth operation on torch 2.5.x.
try:
    import transformers.modeling_utils as modeling_utils
    import transformers.utils.import_utils as import_utils
    modeling_utils.check_torch_load_is_safe = lambda: None
    import_utils.check_torch_load_is_safe = lambda: None
except Exception:
    pass

from transformers import AutoModelForSequenceClassification, AutoTokenizer
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable

# ------------------------------------------------------------
# ENVIRONMENT & DEVICE SETUP
# ------------------------------------------------------------
load_dotenv()
HF_TOKEN = os.getenv("HF_TOKEN")

# Automatically select NVIDIA GPU (CUDA) if available for ~300ms inference
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
DEVICE_NAME = torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU"

# ------------------------------------------------------------
# PAGE CONFIGURATION
# ------------------------------------------------------------
st.set_page_config(
    page_title="Trace Toxic AI — Digital Safety & Bullying Detection",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ------------------------------------------------------------
# CUSTOM MODERN CSS STYLING
# ------------------------------------------------------------
st.markdown(
    """
    <style>
    .stApp {
        background: linear-gradient(135deg, #0b091a 0%, #1a163a 50%, #16122e 100%);
        color: #f1f5f9;
        font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    }

    .card {
        background: rgba(255, 255, 255, 0.04);
        backdrop-filter: blur(12px);
        border: 1px solid rgba(255, 255, 255, 0.08);
        padding: 22px;
        border-radius: 16px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.35);
        margin-bottom: 22px;
    }

    .card-metric {
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 12px;
        padding: 16px;
        text-align: center;
    }

    .metric-value {
        font-size: 28px;
        font-weight: 800;
        margin-top: 4px;
        margin-bottom: 2px;
    }

    .metric-label {
        font-size: 13px;
        text-transform: uppercase;
        letter-spacing: 1px;
        color: #94a3b8;
    }

    h1, h2, h3, h4, h5, h6 {
        color: #38bdf8;
        font-weight: 700;
        letter-spacing: -0.5px;
    }

    .stButton > button {
        background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
        color: #ffffff;
        font-weight: 700;
        border: none;
        border-radius: 10px;
        padding: 12px 24px;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 0 4px 14px rgba(37, 99, 235, 0.4);
    }

    .stButton > button:hover {
        background: linear-gradient(135deg, #ec4899 0%, #d946ef 100%);
        color: #ffffff;
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(217, 70, 239, 0.5);
    }

    .alert-high {
        background: linear-gradient(135deg, rgba(239, 68, 68, 0.85), rgba(185, 28, 28, 0.95));
        border: 2px solid #ef4444;
        animation: pulseAlert 1.5s infinite alternate;
        padding: 18px;
        border-radius: 12px;
        text-align: center;
        font-weight: 800;
        font-size: 19px;
        color: #ffffff;
        box-shadow: 0 0 25px rgba(239, 68, 68, 0.6);
        margin-bottom: 20px;
    }

    .alert-medium {
        background: linear-gradient(135deg, rgba(245, 158, 11, 0.85), rgba(217, 119, 6, 0.9));
        border: 1px solid #f59e0b;
        padding: 16px;
        border-radius: 12px;
        text-align: center;
        font-weight: 700;
        font-size: 17px;
        color: #ffffff;
        margin-bottom: 20px;
    }

    .alert-low {
        background: linear-gradient(135deg, rgba(16, 185, 129, 0.85), rgba(5, 150, 105, 0.9));
        border: 1px solid #10b981;
        padding: 16px;
        border-radius: 12px;
        text-align: center;
        font-weight: 700;
        font-size: 17px;
        color: #ffffff;
        margin-bottom: 20px;
    }

    @keyframes pulseAlert {
        0% { transform: scale(0.99); box-shadow: 0 0 15px rgba(239, 68, 68, 0.4); }
        100% { transform: scale(1.01); box-shadow: 0 0 30px rgba(239, 68, 68, 0.8); }
    }

    .badge-chip {
        display: inline-block;
        padding: 6px 14px;
        border-radius: 9999px;
        font-size: 13px;
        font-weight: 600;
        margin: 4px 6px 4px 0;
        background: rgba(56, 189, 248, 0.15);
        color: #38bdf8;
        border: 1px solid rgba(56, 189, 248, 0.3);
    }

    .badge-chip-danger {
        background: rgba(239, 68, 68, 0.2);
        color: #fca5a5;
        border: 1px solid rgba(239, 68, 68, 0.4);
    }

    .device-pill {
        display: inline-flex;
        align-items: center;
        background: rgba(16, 185, 129, 0.15);
        color: #34d399;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        border: 1px solid rgba(16, 185, 129, 0.3);
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# ------------------------------------------------------------
# CONFIGURATION & DICTIONARIES
# ------------------------------------------------------------
TOXIC_LABELS = [
    "toxic",
    "severe_toxic",
    "obscene",
    "threat",
    "insult",
    "identity_hate",
]

SLANG_MAP = {
    "u": "you",
    "ur": "your",
    "r": "are",
    "brb": "be right back",
    "idk": "i do not know",
    "wtf": "what the fuck",
    "stfu": "shut the fuck up",
    "kys": "kill yourself",
    "gtfo": "get the fuck out",
    "lmao": "laughing my ass off",
    "rofl": "rolling on the floor laughing",
    "smh": "shaking my head",
    "tbh": "to be honest",
    "imo": "in my opinion",
    "bitch": "bitch",
    "loser": "loser",
    "noob": "beginner",
}

EMOJI_MAP = {
    "😡": " rage ",
    "🤬": " swearing rage ",
    "🔥": " aggressive intensity ",
    "👎": " severe dislike ",
    "😢": " sadness ",
    "😭": " crying distress ",
    "😂": " mocking laughter ",
    "💀": " death intimidation ",
    "🤡": " clown mocking ",
    "🤮": " disgust ",
    "🔪": " violence threat ",
    "👊": " physical attack ",
    "💔": " heartbreak ",
}

CATEGORY_KEYWORDS = {
    "Direct Physical Threat": [
        "kill you", "i will kill", "i will beat", "i will hurt", "i'll kill",
        "break your neck", "end your life", "you're dead", "watch your back",
        "hunt you down", "die", "gonna get you", "cut you", "strangle you"
    ],
    "Severe Harassment": [
        "stupid", "idiot", "moron", "shut up", "dumb", "loser",
        "worthless piece of shit", "stfu", "get lost", "waste of space",
        "nobody wants you", "drop dead"
    ],
    "Humiliation & Degradation": [
        "pathetic", "disgusting", "worthless", "embarrassment", "freak",
        "everyone hates you", "no one cares about you", "joke of a person"
    ],
    "Social Exclusion & Mobbing": [
        "nobody likes you", "ignore him", "ignore her", "we wont invite",
        "you are not welcome", "dont talk to them", "kick them out", "unfriend",
        "block him", "block her", "leave the group"
    ],
    "Identity Hate & Racism": [
        "you people", "go back to your country", "racial", "immigrant",
        "hate your kind", "terrorist", "subhuman"
    ],
    "Body Shaming": [
        "fat", "ugly", "skinny", "gross body", "pig", "whale", "hideous",
        "disgusting face"
    ],
    "Sexual Bullying & Harassment": [
        "slut", "whore", "porn", "sexual", "send nudes", "creep", "pervert",
        "stripper"
    ],
    "Gaslighting & Psychological Abuse": [
        "you are crazy", "you are overreacting", "it never happened",
        "you are imagining things", "its all in your head", "you are paranoid",
        "stop acting crazy"
    ],
}

SAMPLE_PRESETS = {
    "1. Severe Violent Threat": "I know where you live, watch your back because I will find you and beat you until you can't walk 😡🔪",
    "2. Cyber-Mobbing & Exclusion": "Nobody in this school likes you. Delete your account and leave our Discord server, you pathetic loser 😂🤡",
    "3. Identity Hate & Slurs": "You people don't belong here, go back to where you came from, we hate your disgusting kind 🤬",
    "4. Body Shaming & Humiliation": "Look in the mirror, you are hideous and fat. It is disgusting how ugly you are 🤮",
    "5. Gaming Lobby Rage (Slang)": "u r such an idiot, uninstall the game kys stfu noob gtfo 💀",
    "6. Benign Friendly Message": "Hey! Great job on the presentation today, everyone really loved your ideas! Keep it up 😊",
}

# ------------------------------------------------------------
# MODEL LOADING WITH FALLBACK & GPU ACCELERATION
# ------------------------------------------------------------
@st.cache_resource(show_spinner=False)
def load_models():
    """
    Loads toxic-bert and emotion distilroberta models.
    Supports CUDA GPU acceleration, safetensors, and graceful fallback.
    """
    toxic_name = "unitary/toxic-bert"
    emotion_name = "j-hartmann/emotion-english-distilroberta-base"

    common_kwargs = {}
    if HF_TOKEN:
        common_kwargs["token"] = HF_TOKEN

    try:
        # Load toxic-bert
        toxic_tokenizer = AutoTokenizer.from_pretrained(
            toxic_name,
            **common_kwargs,
        )
        toxic_model = AutoModelForSequenceClassification.from_pretrained(
            toxic_name,
            use_safetensors=True,
            **common_kwargs,
        ).to(DEVICE)
        toxic_model.eval()

        # Load emotion model
        emo_tokenizer = AutoTokenizer.from_pretrained(
            emotion_name,
            **common_kwargs,
        )
        emo_model = AutoModelForSequenceClassification.from_pretrained(
            emotion_name,
            **common_kwargs,
        ).to(DEVICE)
        emo_model.eval()

        return toxic_tokenizer, toxic_model, emo_tokenizer, emo_model, True, None
    except Exception as e:
        # Return fallback flag if network or dependencies fail
        return None, None, None, None, False, str(e)


# ------------------------------------------------------------
# TEXT PROCESSING HELPERS
# ------------------------------------------------------------
def anonymize_text(text: str) -> str:
    """
    Strips and redacts sensitive PII (Phone numbers, emails, links, @mentions).
    """
    # Phone numbers (international, hyphenated, parenthesized, 10-digit)
    text = re.sub(
        r"(\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b",
        "[REDACTED PHONE]",
        text,
    )
    text = re.sub(r"\b\d{10}\b", "[REDACTED PHONE]", text)
    # Emails
    text = re.sub(r"[\w\.-]+@[\w\.-]+\.\w+", "[REDACTED EMAIL]", text)
    # URLs & Links
    text = re.sub(r"https?://\S+|www\.\S+", "[REDACTED URL]", text)
    # User handles
    text = re.sub(r"@[\w_]+", "[REDACTED USER]", text)
    return text


def normalize_text(text: str) -> str:
    """
    Replaces emojis, expands internet slang using regex boundaries,
    and collapses elongated characters (e.g. looooser -> looser).
    """
    # Emojis to semantic meaning
    for emoji, meaning in EMOJI_MAP.items():
        text = text.replace(emoji, meaning)

    # Collapse elongated characters
    text = re.sub(r"(.)\1{2,}", r"\1\1", text)

    # Replace slang using regex word boundaries to preserve surrounding punctuation
    for slang, replacement in SLANG_MAP.items():
        pattern = r"\b" + re.escape(slang) + r"\b"
        text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)

    # Clean whitespace
    text = re.sub(r"\s+", " ", text).strip()
    return text


# ------------------------------------------------------------
# INFERENCE ENGINES (DL + HEURISTIC FALLBACK)
# ------------------------------------------------------------
def detect_toxicity_dl(text: str, toxic_tokenizer, toxic_model) -> dict:
    inputs = toxic_tokenizer(
        text,
        return_tensors="pt",
        truncation=True,
        padding=True,
        max_length=512,
    ).to(DEVICE)

    with torch.no_grad():
        outputs = toxic_model(**inputs)

    probabilities = torch.sigmoid(outputs.logits)[0].cpu().numpy()

    results = {}
    for i, score in enumerate(probabilities):
        label = toxic_model.config.id2label.get(
            i, TOXIC_LABELS[i] if i < len(TOXIC_LABELS) else f"label_{i}"
        )
        results[label] = round(float(score * 100), 2)

    return results


def detect_emotion_dl(text: str, emo_tokenizer, emo_model):
    inputs = emo_tokenizer(
        text,
        return_tensors="pt",
        truncation=True,
        padding=True,
        max_length=512,
    ).to(DEVICE)

    with torch.no_grad():
        outputs = emo_model(**inputs)

    probabilities = torch.softmax(outputs.logits, dim=1)[0].cpu().numpy()

    all_emotions = {}
    for i, score in enumerate(probabilities):
        label = emo_model.config.id2label[i]
        all_emotions[label] = round(float(score * 100), 2)

    best_index = int(np.argmax(probabilities))
    top_emotion = emo_model.config.id2label[best_index]
    top_confidence = float(probabilities[best_index])

    return top_emotion, top_confidence, all_emotions


def detect_toxicity_fallback(text: str) -> dict:
    """High-precision heuristic fallback if deep learning models are offline."""
    text_l = text.lower()
    threat_kw = CATEGORY_KEYWORDS["Direct Physical Threat"]
    harass_kw = CATEGORY_KEYWORDS["Severe Harassment"]
    humil_kw = CATEGORY_KEYWORDS["Humiliation & Degradation"]
    hate_kw = CATEGORY_KEYWORDS["Identity Hate & Racism"]

    threat_hit = any(k in text_l for k in threat_kw)
    harass_hit = any(k in text_l for k in harass_kw)
    humil_hit = any(k in text_l for k in humil_kw)
    hate_hit = any(k in text_l for k in hate_kw)

    toxic_score = 90.0 if (threat_hit or harass_hit or humil_hit) else 10.0
    threat_score = 88.0 if threat_hit else 5.0
    insult_score = 85.0 if harass_hit else 12.0
    hate_score = 80.0 if hate_hit else 4.0
    obscene_score = 65.0 if ("fuck" in text_l or "shit" in text_l) else 8.0
    severe_score = 75.0 if (threat_hit and harass_hit) else 15.0

    return {
        "toxic": toxic_score,
        "severe_toxic": severe_score,
        "obscene": obscene_score,
        "threat": threat_score,
        "insult": insult_score,
        "identity_hate": hate_score,
    }


def detect_emotion_fallback(text: str):
    """Rule-based emotion estimation fallback."""
    text_l = text.lower()
    if any(k in text_l for k in ["kill", "beat", "hate", "idiot", "die", "rage", "shut up"]):
        return "anger", 0.88, {"anger": 88.0, "disgust": 8.0, "fear": 2.0, "sadness": 1.0, "joy": 0.5, "neutral": 0.5, "surprise": 0.0}
    elif any(k in text_l for k in ["ugly", "gross", "fat", "pathetic", "disgusting"]):
        return "disgust", 0.82, {"disgust": 82.0, "anger": 12.0, "sadness": 4.0, "fear": 1.0, "joy": 0.5, "neutral": 0.5, "surprise": 0.0}
    elif any(k in text_l for k in ["great", "love", "awesome", "good", "happy", "congrats"]):
        return "joy", 0.94, {"joy": 94.0, "neutral": 4.0, "surprise": 1.0, "anger": 0.3, "disgust": 0.3, "fear": 0.2, "sadness": 0.2}
    else:
        return "neutral", 0.70, {"neutral": 70.0, "joy": 10.0, "sadness": 10.0, "anger": 5.0, "disgust": 2.0, "fear": 2.0, "surprise": 1.0}


def detect_categories(text: str, toxic_scores: dict) -> list:
    text_l = text.lower()
    detected = []

    for category, keywords in CATEGORY_KEYWORDS.items():
        if any(keyword in text_l for keyword in keywords):
            detected.append(category)

    # Augment with model thresholds
    if toxic_scores.get("threat", 0) >= 45 and "Direct Physical Threat" not in detected:
        detected.append("Direct Physical Threat")
    if (toxic_scores.get("insult", 0) >= 50 or toxic_scores.get("toxic", 0) >= 75) and "Severe Harassment" not in detected:
        detected.append("Severe Harassment")
    if toxic_scores.get("identity_hate", 0) >= 35 and "Identity Hate & Racism" not in detected:
        detected.append("Identity Hate & Racism")
    if toxic_scores.get("obscene", 0) >= 60 and "Obscenity & Vulgarity" not in detected:
        detected.append("Obscenity & Vulgarity")

    return detected or ["None (Benign)"]


def compute_severity(toxic_scores: dict, all_emotions: dict) -> float:
    """
    Multi-dimensional severity index (0 - 100) combining toxicity dimensions
    modulated by negative emotional intensity.
    """
    toxic = toxic_scores.get("toxic", 0) / 100
    severe_toxic = toxic_scores.get("severe_toxic", 0) / 100
    threat = toxic_scores.get("threat", 0) / 100
    insult = toxic_scores.get("insult", 0) / 100
    obscene = toxic_scores.get("obscene", 0) / 100
    identity_hate = toxic_scores.get("identity_hate", 0) / 100

    raw_score = (
        0.25 * toxic
        + 0.20 * severe_toxic
        + 0.25 * threat
        + 0.15 * insult
        + 0.05 * obscene
        + 0.10 * identity_hate
    )

    # Emotion amplification factor (high anger or disgust elevates severity)
    anger = all_emotions.get("anger", 0) / 100
    disgust = all_emotions.get("disgust", 0) / 100
    modulator = 1.0 + 0.15 * max(anger, disgust)

    final_severity = min(100.0, raw_score * 100 * modulator)
    return round(final_severity, 2)


# ------------------------------------------------------------
# IN-MEMORY REPORTLAB PDF GENERATOR (Zero Windows File Locks)
# ------------------------------------------------------------
def generate_pdf(
    raw_text: str,
    anonymized_text: str,
    toxicity: dict,
    top_emotion: str,
    emotion_confidence: float,
    all_emotions: dict,
    categories: list,
    severity: float,
    engine_name: str,
) -> bytes:
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        leftMargin=40,
        rightMargin=40,
        topMargin=40,
        bottomMargin=40,
    )

    styles = getSampleStyleSheet()
    story = []

    # Title & Branding
    title_style = ParagraphStyle(
        "DocTitle",
        parent=styles["Heading1"],
        fontSize=22,
        textColor=colors.HexColor("#0f172a"),
        spaceAfter=4,
    )
    subtitle_style = ParagraphStyle(
        "DocSub",
        parent=styles["Normal"],
        fontSize=10,
        textColor=colors.HexColor("#64748b"),
        spaceAfter=15,
    )

    story.append(Paragraph("🛡️ TRACE TOXIC AI — DIGITAL SAFETY INCIDENT REPORT", title_style))
    now_str = datetime.now().strftime("%B %d, %Y at %I:%M:%S %p")
    doc_id = f"INC-{datetime.now().strftime('%Y%m%d')}-{np.random.randint(1000, 9999)}"
    story.append(Paragraph(f"Reference ID: <b>{doc_id}</b> | Generated: {now_str} | Engine: {engine_name}", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor("#3b82f6"), spaceAfter=15))

    # Risk Classification Callout
    risk_title = "CRITICAL / HIGH RISK" if severity >= 70 else ("MODERATE RISK" if severity >= 40 else "LOW / SAFE")
    risk_color = colors.HexColor("#ef4444") if severity >= 70 else (colors.HexColor("#f59e0b") if severity >= 40 else colors.HexColor("#10b981"))

    risk_data = [
        [
            Paragraph(f"<b>RISK LEVEL:</b> {risk_title}", ParagraphStyle("RiskT", parent=styles["Normal"], textColor=colors.white, fontName="Helvetica-Bold", fontSize=12)),
            Paragraph(f"<b>SEVERITY SCORE:</b> {severity}/100", ParagraphStyle("RiskS", parent=styles["Normal"], textColor=colors.white, fontName="Helvetica-Bold", fontSize=12, alignment=2))
        ]
    ]
    t_risk = Table(risk_data, colWidths=[260, 260])
    t_risk.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), risk_color),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("LEFTPADDING", (0, 0), (-1, -1), 12),
        ("RIGHTPADDING", (0, 0), (-1, -1), 12),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    story.append(t_risk)
    story.append(Spacer(1, 15))

    # Section: Evaluated Text (Sanitized)
    h2_style = ParagraphStyle("H2", parent=styles["Heading2"], fontSize=13, textColor=colors.HexColor("#1e293b"), spaceAfter=6)
    story.append(Paragraph("1. Evaluated Content (Sanitized & Anonymized)", h2_style))

    safe_text = saxutils.escape(anonymized_text).replace("\n", "<br/>")
    text_table = Table([[Paragraph(f"<i>\"{safe_text}\"</i>", styles["Normal"])]], colWidths=[520])
    text_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f8fafc")),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
        ("TOPPADDING", (0, 0), (-1, -1), 10),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ("LEFTPADDING", (0, 0), (-1, -1), 12),
        ("RIGHTPADDING", (0, 0), (-1, -1), 12),
    ]))
    story.append(text_table)
    story.append(Spacer(1, 15))

    # Section: Toxicity Breakdown Table
    story.append(Paragraph("2. Deep Toxicity Analysis", h2_style))
    tox_rows = [["Toxicity Dimension", "Confidence Score", "Risk Tier"]]
    for k, v in toxicity.items():
        tier = "Critical (>70%)" if v >= 70 else ("Moderate (40-69%)" if v >= 40 else "Safe (<40%)")
        tox_rows.append([k.replace("_", " ").title(), f"{v:.2f}%", tier])

    t_tox = Table(tox_rows, colWidths=[200, 160, 160])
    t_tox.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1e293b")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e2e8f0")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f8fafc")]),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(t_tox)
    story.append(Spacer(1, 15))

    # Section: Emotion & Categorization
    story.append(Paragraph("3. Psychological & Bullying Classification", h2_style))
    cats_str = ", ".join(categories)
    emo_summary = f"<b>Primary Emotion:</b> {top_emotion.title()} ({emotion_confidence*100:.1f}% confidence)<br/><b>Identified Bullying Patterns:</b> {cats_str}"
    p_emo = Paragraph(emo_summary, styles["Normal"])
    emo_table = Table([[p_emo]], colWidths=[520])
    emo_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f1f5f9")),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
    ]))
    story.append(emo_table)
    story.append(Spacer(1, 15))

    # Section: Recommendations
    story.append(Paragraph("4. Recommended Safety Measures & Evidence Preservation", h2_style))
    if severity >= 70:
        rec_text = (
            "• <b>Immediate Evidence Preservation:</b> Do not delete messages from the messaging platform. Preserve original digital screenshots with timestamps.<br/>"
            "• <b>Block and Report:</b> Block the sender across all connected social channels.<br/>"
            "• <b>Emergency / Legal Escalation:</b> If an immediate threat of physical harm exists, contact local authorities or the National Cyber Crime Portal (1930 / cybercrime.gov.in)."
        )
    elif severity >= 40:
        rec_text = (
            "• <b>Set Boundaries:</b> Restrict or mute notifications from this sender.<br/>"
            "• <b>Document Patterns:</b> Keep a log if repetitive harassment occurs.<br/>"
            "• <b>Support Contact:</b> Speak with a trusted peer, mentor, or school counselor."
        )
    else:
        rec_text = (
            "• Content analyzed does not exhibit severe cyberbullying or immediate safety risks.<br/>"
            "• Normal routine digital interaction recommended."
        )

    p_rec = Paragraph(rec_text, styles["Normal"])
    rec_table = Table([[p_rec]], colWidths=[520])
    rec_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#eff6ff")),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#bfdbfe")),
        ("TOPPADDING", (0, 0), (-1, -1), 10),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ("LEFTPADDING", (0, 0), (-1, -1), 12),
    ]))
    story.append(rec_table)

    # Footer note
    story.append(Spacer(1, 20))
    story.append(Paragraph("<i>Disclaimer: Trace Toxic AI is an automated screening and early warning aid. Consult professional or legal authorities for actionable legal interventions.</i>", ParagraphStyle("Foot", parent=styles["Normal"], fontSize=8, textColor=colors.HexColor("#94a3b8"))))

    doc.build(story)
    pdf_bytes = buffer.getvalue()
    buffer.close()
    return pdf_bytes


# ------------------------------------------------------------
# APPLICATION BOOTSTRAP & STATE
# ------------------------------------------------------------
# Load models into cache
with st.spinner("Initializing AI Detection Models & CUDA Engine..."):
    toxic_tokenizer, toxic_model, emo_tokenizer, emo_model, models_loaded, load_err = load_models()

# Initialize Session State
if "analysis_result" not in st.session_state:
    st.session_state.analysis_result = None
if "history" not in st.session_state:
    st.session_state.history = []

# ------------------------------------------------------------
# SIDEBAR
# ------------------------------------------------------------
with st.sidebar:
    st.image("https://img.icons8.com/fluency/96/shield.png", width=64)
    st.title("System Control")

    # Hardware & Model Status Pill
    if models_loaded:
        st.markdown(
            f"""
            <div class='device-pill'>
                ● AI Acceleration: {DEVICE_NAME} ({DEVICE.upper()})
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.caption(f"Models: `toxic-bert` & `emotion-distilroberta`")
    else:
        st.warning("⚠️ Running in Heuristic Fallback Mode")
        if load_err:
            with st.expander("Diagnostic Info"):
                st.code(load_err)
        if st.button("🔄 Retry Model Load"):
            st.cache_resource.clear()
            st.rerun()

    st.markdown("---")

    st.subheader("⚙️ Analysis Settings")
    show_anonymized = st.toggle("View Anonymized Text", value=True, help="Toggle between original input and sanitized/redacted PII text.")
    strict_mode = st.toggle("Strict Bullying Threshold", value=False, help="Lower thresholds to detect subtle micro-aggressions.")

    st.markdown("---")
    st.subheader("💡 Emergency Resources")
    st.markdown("""
    - **Cyber Crime Portal:** [cybercrime.gov.in](https://cybercrime.gov.in)
    - **Cyber Helpline:** `1930`
    - **Childline / Teen Support:** `1098`
    - **National Suicide & Crisis:** `988` (US) / `14416` (Tele-MANAS)
    """)

    if st.session_state.history:
        st.markdown("---")
        st.caption(f"Recent Scans in Session: {len(st.session_state.history)}")
        if st.button("🗑️ Clear Scan History"):
            st.session_state.history = []
            st.session_state.analysis_result = None
            st.rerun()

# ------------------------------------------------------------
# MAIN USER INTERFACE
# ------------------------------------------------------------
st.title("🛡️ Trace Toxic AI")
st.markdown("### Bullying Detection, Emotion Profiling & Early Warning System")

st.markdown(
    """
    <div class='card'>
        <h4 style='margin-top:0; color:#38bdf8;'>🔒 Privacy-First Intelligent Triage</h4>
        <p style='margin-bottom:0; color:#cbd5e1; font-size:14.5px;'>
            Communications are sanitized locally on your device. Phone numbers, personal emails, external links,
            and handles are automatically redacted before deep linguistic analysis using Hugging Face Transformer models.
        </p>
    </div>
    """,
    unsafe_allow_html=True,
)

# Input Selector Tabs
input_method = st.radio(
    "Choose Input Method:",
    ["Manual Text & Presets", "Upload File (.txt / .csv)", "Notification Simulator"],
    horizontal=True,
)

input_text = ""

if input_method == "Manual Text & Presets":
    col_pre1, col_pre2 = st.columns([1, 2])
    with col_pre1:
        selected_preset = st.selectbox(
            "Load Quick Test Scenario:",
            ["-- Choose a preset scenario --"] + list(SAMPLE_PRESETS.keys()),
        )
    with col_pre2:
        st.caption("Select a scenario to auto-fill the analyzer, or enter any custom text below.")

    default_val = SAMPLE_PRESETS[selected_preset] if selected_preset in SAMPLE_PRESETS else ""
    input_text = st.text_area(
        "Enter or Paste Message:",
        value=default_val,
        height=140,
        placeholder="Example: You are stupid and nobody likes you. Stop talking to us.",
    )

elif input_method == "Upload File (.txt / .csv)":
    uploaded_file = st.file_uploader(
        "Upload Text or Chat Export (.txt, .csv)",
        type=["txt", "csv"],
        help="Upload exported chat logs or text files.",
    )

    if uploaded_file:
        try:
            content = uploaded_file.read().decode("utf-8")
            lines = [line.strip() for line in content.splitlines() if line.strip()]

            if len(lines) > 1:
                st.info(f"Loaded {len(lines)} lines from `{uploaded_file.name}`. Select a message line to analyze:")
                selected_line_idx = st.selectbox(
                    "Select message line:",
                    range(len(lines)),
                    format_func=lambda idx: f"Line {idx+1}: {lines[idx][:65]}...",
                )
                input_text = lines[selected_line_idx]
            else:
                input_text = content
        except UnicodeDecodeError:
            st.error("Error: Please upload a standard UTF-8 encoded text or CSV file.")
    else:
        st.caption("Upload a file above to inspect conversations.")

else:
    # Notification Simulator
    st.markdown("#### 📱 Simulate Mobile Notification Stream")
    col_sim1, col_sim2 = st.columns([1, 2])
    with col_sim1:
        sim_app = st.selectbox("App Source", ["WhatsApp", "Instagram Direct", "Discord", "Telegram", "X (Twitter)", "SMS"])
        sim_sender = st.text_input("Sender Name / Handle", value="gamer_killer99")
    with col_sim2:
        sim_msg = st.text_area(
            "Notification Message Body",
            value="u r dead meat, we found your address and we are coming for you tonight 😡🔪",
            height=100,
        )
    input_text = sim_msg

# Action Buttons
col_btn1, col_btn2 = st.columns([3, 1])
with col_btn1:
    analyze_clicked = st.button("🔍 Analyze Message & Evaluate Safety", use_container_width=True)
with col_btn2:
    if st.button("🔄 Reset / Clear", use_container_width=True):
        st.session_state.analysis_result = None
        st.rerun()

# ------------------------------------------------------------
# ANALYSIS EXECUTION
# ------------------------------------------------------------
if analyze_clicked:
    if not input_text.strip():
        st.warning("Please enter or select a message to analyze first.")
    else:
        with st.spinner("Processing text, anonymizing PII, and running neural models..."):
            # 1. Anonymization & Normalization
            anonymized = anonymize_text(input_text)
            normalized = normalize_text(anonymized)

            # 2. Neural or Heuristic Inference
            if models_loaded:
                toxic_scores = detect_toxicity_dl(normalized, toxic_tokenizer, toxic_model)
                top_emo, emo_conf, all_emotions = detect_emotion_dl(normalized, emo_tokenizer, emo_model)
                engine_used = f"HuggingFace Transformers (CUDA / {DEVICE_NAME})"
            else:
                toxic_scores = detect_toxicity_fallback(normalized)
                top_emo, emo_conf, all_emotions = detect_emotion_fallback(normalized)
                engine_used = "Heuristic & Lexicon Safety Fallback"

            # 3. Categorization & Severity
            categories = detect_categories(normalized, toxic_scores)
            severity = compute_severity(toxic_scores, all_emotions)

            # Store in Session State to prevent disappearance on download
            st.session_state.analysis_result = {
                "raw_text": input_text,
                "anonymized_text": anonymized,
                "normalized_text": normalized,
                "toxic_scores": toxic_scores,
                "top_emo": top_emo,
                "emo_conf": emo_conf,
                "all_emotions": all_emotions,
                "categories": categories,
                "severity": severity,
                "engine_used": engine_used,
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }

            # Add to history
            st.session_state.history.append({
                "time": datetime.now().strftime("%H:%M:%S"),
                "text": input_text[:40] + "..." if len(input_text) > 40 else input_text,
                "severity": severity,
                "risk": "High" if severity >= 70 else ("Moderate" if severity >= 40 else "Low"),
            })

# ------------------------------------------------------------
# DISPLAY RESULTS (Rendered persistently from Session State)
# ------------------------------------------------------------
if st.session_state.analysis_result:
    res = st.session_state.analysis_result
    severity = res["severity"]
    toxic_scores = res["toxic_scores"]
    top_emo = res["top_emo"]
    emo_conf = res["emo_conf"]
    all_emotions = res["all_emotions"]
    categories = res["categories"]
    engine_used = res["engine_used"]

    st.markdown("---")

    # Risk Alert Banner
    if severity >= 70:
        st.markdown(
            """
            <div class="alert-high">
                🚨 CRITICAL / HIGH-RISK INCIDENT DETECTED! 🚨<br/>
                <span style="font-size:14px; font-weight:normal;">
                    Immediate protective actions and evidence preservation advised.
                </span>
            </div>
            """,
            unsafe_allow_html=True,
        )
    elif severity >= 40:
        st.markdown(
            """
            <div class="alert-medium">
                ⚠️ MODERATE RISK: Bullying or Harassment Signals Detected<br/>
                <span style="font-size:14px; font-weight:normal;">
                    Pattern monitoring and conversation de-escalation recommended.
                </span>
            </div>
            """,
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            """
            <div class="alert-low">
                ✅ LOW RISK: Content Appears Safe and Non-Threatening<br/>
                <span style="font-size:14px; font-weight:normal;">
                    No immediate hostile or cyberbullying markers detected.
                </span>
            </div>
            """,
            unsafe_allow_html=True,
        )

    # Privacy View Inspection
    with st.expander("👁️ Inspect Sanitized & Normalized Data", expanded=False):
        col_t1, col_t2 = st.columns(2)
        with col_t1:
            st.caption("Original Raw Message:")
            st.code(res["raw_text"])
        with col_t2:
            st.caption("Sanitized & PII-Redacted Text (Analyzed):")
            st.code(res["anonymized_text"])

    # High-level Metrics Row
    m_col1, m_col2, m_col3, m_col4 = st.columns(4)
    with m_col1:
        st.markdown(
            f"""
            <div class='card-metric'>
                <div class='metric-label'>Severity Index</div>
                <div class='metric-value' style='color: {"#ef4444" if severity>=70 else ("#f59e0b" if severity>=40 else "#10b981")}'>
                    {severity:.1f}<span style='font-size:16px;'>/100</span>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with m_col2:
        top_tox_label = max(toxic_scores, key=toxic_scores.get)
        top_tox_val = toxic_scores[top_tox_label]
        st.markdown(
            f"""
            <div class='card-metric'>
                <div class='metric-label'>Peak Toxicity</div>
                <div class='metric-value' style='color:#38bdf8;'>
                    {top_tox_val:.1f}%
                </div>
                <div style='font-size:11px; color:#94a3b8;'>{top_tox_label.replace('_', ' ').title()}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with m_col3:
        emo_icons = {"anger": "😡", "disgust": "🤢", "fear": "😨", "joy": "😊", "neutral": "😐", "sadness": "😢", "surprise": "😲"}
        icon = emo_icons.get(top_emo.lower(), "🎯")
        st.markdown(
            f"""
            <div class='card-metric'>
                <div class='metric-label'>Primary Emotion</div>
                <div class='metric-value' style='color:#f472b6;'>
                    {icon} {top_emo.title()}
                </div>
                <div style='font-size:11px; color:#94a3b8;'>{emo_conf*100:.1f}% Confidence</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with m_col4:
        st.markdown(
            f"""
            <div class='card-metric'>
                <div class='metric-label'>Patterns Flagged</div>
                <div class='metric-value' style='color:#a78bfa;'>
                    {len(categories) if categories != ['None (Benign)'] else 0}
                </div>
                <div style='font-size:11px; color:#94a3b8;'>Categories</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.markdown("<br/>", unsafe_allow_html=True)

    # Two-Column Detailed Breakdown
    col_left, col_right = st.columns([1.1, 0.9])

    with col_left:
        st.markdown("### 🧪 Toxicity Category Breakdown")

        # Color-coded Plotly bar chart
        bar_colors = []
        for val in toxic_scores.values():
            if val >= 70:
                bar_colors.append("#ef4444")
            elif val >= 40:
                bar_colors.append("#f59e0b")
            else:
                bar_colors.append("#10b981")

        labels = [k.replace("_", " ").title() for k in toxic_scores.keys()]
        values = list(toxic_scores.values())

        fig_tox = go.Figure(
            data=[
                go.Bar(
                    x=labels,
                    y=values,
                    text=[f"{v:.1f}%" for v in values],
                    textposition="auto",
                    marker=dict(
                        color=bar_colors,
                        line=dict(color="rgba(255,255,255,0.2)", width=1),
                    ),
                    hovertemplate="<b>%{x}</b>: %{y:.2f}%<extra></extra>",
                )
            ]
        )

        fig_tox.update_layout(
            height=320,
            margin=dict(l=20, r=20, t=20, b=20),
            xaxis=dict(tickangle=-25, showgrid=False),
            yaxis=dict(range=[0, 100], showgrid=True, gridcolor="rgba(255,255,255,0.06)"),
            plot_bgcolor="rgba(0,0,0,0)",
            paper_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#e2e8f0", size=12),
        )
        st.plotly_chart(fig_tox, use_container_width=True)

        st.markdown("### 🎯 Bullying & Harassment Categories")
        if categories == ["None (Benign)"]:
            st.success("✅ No overt bullying or harassment patterns detected.")
        else:
            cat_chips = "".join([f"<span class='badge-chip badge-chip-danger'>⚠️ {c}</span>" for c in categories])
            st.markdown(f"<div>{cat_chips}</div>", unsafe_allow_html=True)

    with col_right:
        st.markdown("### 🎭 Emotion Distribution")

        # Radar chart for emotions
        emo_keys = [k.title() for k in all_emotions.keys()]
        emo_vals = list(all_emotions.values())
        # Close radar loop
        emo_keys_loop = emo_keys + [emo_keys[0]]
        emo_vals_loop = emo_vals + [emo_vals[0]]

        fig_emo = go.Figure(
            data=[
                go.Scatterpolar(
                    r=emo_vals_loop,
                    theta=emo_keys_loop,
                    fill="toself",
                    fillcolor="rgba(56, 189, 248, 0.25)",
                    line=dict(color="#38bdf8", width=2),
                    hovertemplate="<b>%{theta}</b>: %{r:.1f}%<extra></extra>",
                )
            ]
        )
        fig_emo.update_layout(
            height=320,
            margin=dict(l=30, r=30, t=20, b=20),
            polar=dict(
                radialaxis=dict(visible=True, range=[0, 100], showticklabels=False, linecolor="rgba(255,255,255,0.1)"),
                angularaxis=dict(linecolor="rgba(255,255,255,0.2)", gridcolor="rgba(255,255,255,0.08)"),
                bgcolor="rgba(0,0,0,0)",
            ),
            paper_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#e2e8f0", size=11),
        )
        st.plotly_chart(fig_emo, use_container_width=True)

        # Safety & Guidance Box
        st.markdown("### 💡 Recommended Actions")
        if "Direct Physical Threat" in categories or severity >= 70:
            st.error(
                "🚨 **URGENT:** High likelihood of imminent threat or harassment. "
                "Preserve all original evidence, block communications, and report to authorities immediately."
            )
        elif severity >= 40:
            st.warning(
                "🛡️ **ADVICE:** Hostile or harassing content detected. "
                "Consider muting or blocking the sender, disengaging from the conversation, and confiding in a trusted adult or peer."
            )
        else:
            st.info(
                "💬 **SAFE:** Content appears civil and benign. Maintain normal healthy digital habits."
            )

    # PDF Report Download Section
    st.markdown("---")
    st.markdown("### 📄 Formal Incident Report")
    st.caption("Generate a court/school-admissible, tamper-evident PDF summary of this incident.")

    pdf_data = generate_pdf(
        raw_text=res["raw_text"],
        anonymized_text=res["anonymized_text"],
        toxicity=toxic_scores,
        top_emotion=top_emo,
        emotion_confidence=emo_conf,
        all_emotions=all_emotions,
        categories=categories,
        severity=severity,
        engine_name=engine_used,
    )

    st.download_button(
        label="📥 Download Official Incident PDF Report",
        data=pdf_data,
        file_name=f"TraceToxic_Report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf",
        mime="application/pdf",
        use_container_width=True,
    )

# Footer
st.markdown("---")
st.caption(
    "🛡️ Trace Toxic AI is designed as a digital safety triage and early warning aid. "
    "For critical emergencies or immediate danger, always contact your local law enforcement or national emergency helpline."
)
